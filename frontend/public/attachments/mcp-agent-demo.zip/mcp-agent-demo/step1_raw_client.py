#!/usr/bin/env python3
"""
第 1 步：不带 agent，纯手动跟 MCP 服务端对话。

目的是让你看清 MCP 到底在干什么 —— 它只做两件事：
    1. list_tools()  →  "我这儿有哪些工具、参数长什么样"
    2. call_tool()   →  "帮我执行这个工具"

跑：python step1_raw_client.py
"""
import asyncio, json, sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

HERE = Path(__file__).parent


async def main():
    # 告诉客户端怎么启动服务端 —— 它就是个子进程
    #   command 用 sys.executable，不要写 "python"：
    #   sys.executable 就是正在跑本文件的解释器，永远正确。
    #   args 用绝对路径：子进程的工作目录不保证是本目录。
    params = StdioServerParameters(
        command=sys.executable,
        args=[str(HERE / "sales_server.py")],
    )

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # ── 能力发现：服务端有什么工具？──────────────────────
            print("=" * 60)
            print("① list_tools() —— 问服务端有什么工具")
            print("=" * 60)
            resp = await session.list_tools()
            for t in resp.tools:
                print(f"\n工具名: {t.name}")
                print(f"描述:   {t.description}")
                # 1.x 是 inputSchema，2.0 改成 input_schema
                schema = getattr(t, "input_schema", None) or t.inputSchema
                print(f"参数:   {json.dumps(schema, ensure_ascii=False)}")

            print("\n" + "=" * 60)
            print("② call_tool() —— 让服务端执行一个工具")
            print("=" * 60)
            result = await session.call_tool("query_sales", {"month": "2026-07"})
            print(f"\ncall_tool('query_sales', month='2026-07') 返回：")
            for c in result.content:
                print(c.text)

            result = await session.call_tool("get_target", {"month": "2026-07"})
            print(f"\ncall_tool('get_target', month='2026-07') 返回：")
            for c in result.content:
                print(c.text)

    print("\n" + "=" * 60)
    print("注意：全程没有大模型参与。")
    print("MCP 只是一个「取工具清单 + 远程执行工具」的协议。")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
