#!/usr/bin/env python3
"""
第 4 步：把服务端打成包 → 当成"已发布的包"装起来 → 连上去用。

真正的 `twine upload` / `mcp-publisher publish` 是**不可逆的公开动作**，
所以这个脚本只做到"本地彩排"这一步：产出物、验证逻辑、连接方式都和
真发布后一模一样，唯独没有把东西推到公网。真发布的命令在 PUBLISH.md。

跑：
    python step4_publish_and_use.py            # 彩排：构建 + 校验 + 连接
    python step4_publish_and_use.py --agent    # 再多一步：让 agent 用它（要 api_key）
"""
import asyncio
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

HERE = Path(__file__).parent
PKG = HERE / "publish"


def head(n: int, title: str) -> None:
    print(f"\n{'=' * 64}\n{n}. {title}\n{'=' * 64}")


# ──────────────────────────────────────────────────────────────
# ① 归属校验：注册表拒绝发布的头号原因就是这两个名字对不上
# ──────────────────────────────────────────────────────────────
def check_ownership_marker() -> str:
    meta = json.loads((PKG / "server.json").read_text(encoding="utf-8"))
    server_name = meta["name"]
    pyproject = (PKG / "pyproject.toml").read_text(encoding="utf-8")
    readme = (PKG / "README.md").read_text(encoding="utf-8")

    found = re.search(r"mcp-name:\s*(\S+)", readme)
    print(f"server.json  name        = {server_name}")
    print(f"README.md    mcp-name    = {found.group(1) if found else '（没找到！）'}")

    if not found:
        sys.exit("✗ README 里缺 `mcp-name:` 标记，PyPI 包发布会被注册表拒掉")
    if found.group(1) != server_name:
        sys.exit(f"✗ 两个名字不一致 → 发布会被拒")
    print("✓ 归属标记一致\n")

    # version 三处也必须一致：server.json 顶层、packages[].version、包本身
    pkg_ver = re.search(r'^version\s*=\s*"([^"]+)"', pyproject, re.M).group(1)
    vers = {"server.json": meta["version"],
            "server.json/packages": meta["packages"][0]["version"],
            "pyproject.toml": pkg_ver}
    print("版本号：", vers)
    if len(set(vers.values())) != 1:
        sys.exit("✗ 版本号不一致 → mcp-publisher 会报校验错误")
    print("✓ 版本号一致")
    return server_name


# ──────────────────────────────────────────────────────────────
# ② 构建：产出的 wheel 就是将来 twine upload 上去的那个文件
# ──────────────────────────────────────────────────────────────
def build_wheel() -> Path:
    if not shutil.which("uv"):
        sys.exit("需要 uv：https://docs.astral.sh/uv/  （或改用 python -m build）")
    shutil.rmtree(PKG / "dist", ignore_errors=True)
    subprocess.run(["uv", "build", "--wheel", "-o", "dist"],
                   cwd=PKG, check=True)
    wheel = next((PKG / "dist").glob("*.whl"))
    print(f"\n✓ 产物: {wheel.name}  ({wheel.stat().st_size // 1024} KB)")
    return wheel


# ──────────────────────────────────────────────────────────────
# ③ 当成"已发布的包"用：uvx 建临时环境装它，跑 console script
#    发布之后别人敲的是 `uvx mcp-sales-db`，
#    这里只是把包源从 PyPI 换成本地 wheel，其余完全一样。
# ──────────────────────────────────────────────────────────────
async def use_as_installed(wheel: Path) -> None:
    params = StdioServerParameters(
        command="uvx",
        args=["--from", str(wheel), "mcp-sales-db"],
    )
    print(f"启动方式: uvx --from {wheel.name} mcp-sales-db")
    print("（uvx 会新建一个隔离环境把 wheel 和它的依赖装进去，再跑入口命令）\n")

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            resp = await session.list_tools()
            print(f"list_tools() → {[t.name for t in resp.tools]}")
            result = await session.call_tool("query_sales", {"month": "2026-07"})
            print("\ncall_tool('query_sales', month='2026-07') →")
            for c in result.content:
                print("  " + c.text.replace("\n", "\n  "))


# ──────────────────────────────────────────────────────────────
# ④ 可选：让 agent 用这个"已发布"的服务端
# ──────────────────────────────────────────────────────────────
async def run_agent(wheel: Path, task: str) -> None:
    from langchain_mcp_adapters.client import MultiServerMCPClient
    from langchain.agents import create_agent
    from mcp_config import CFG, build_llm

    client = MultiServerMCPClient({
        "sales-db-published": {
            "command": "uvx",
            "args": ["--from", str(wheel), "mcp-sales-db"],
            "transport": "stdio",
        }
    })
    tools = await client.get_tools()
    print(f"从已安装的包里拿到工具: {[t.name for t in tools]}\n")

    agent = create_agent(
        model=build_llm(),
        tools=tools,
        system_prompt="你是销售分析助手。按需使用工具，用完直接给结论。",
    )
    result = await agent.ainvoke({"messages": [("user", task)]},
                                 {"recursion_limit": CFG["run"]["max_steps"]})
    print(result["messages"][-1].content)


async def main() -> None:
    head(1, "发布前自检：注册表会查的两件事")
    server_name = check_ownership_marker()

    head(2, "构建：打出要上传到 PyPI 的 wheel")
    wheel = build_wheel()

    head(3, "当成已发布的包来用（uvx 装进隔离环境再连）")
    await use_as_installed(wheel)

    if "--agent" in sys.argv:
        head(4, "让 agent 用这个已安装的服务端")
        task = " ".join(a for a in sys.argv[1:] if not a.startswith("--"))
        await run_agent(wheel, task or "七月销售完成目标了吗")

    head(5 if "--agent" in sys.argv else 4, "真发布的话，接下来是这三条")
    print(f"""
  1) 传包            cd publish && uv publish        # 或 twine upload dist/*
  2) 上架元数据      mcp-publisher login github
                     mcp-publisher validate
                     mcp-publisher publish
  3) 别人就能用      claude mcp add --transport stdio sales-db -- uvx mcp-sales-db

  发布后查一下在不在：
    curl "https://registry.modelcontextprotocol.io/v0.1/servers?search={server_name}"
""")


if __name__ == "__main__":
    asyncio.run(main())
