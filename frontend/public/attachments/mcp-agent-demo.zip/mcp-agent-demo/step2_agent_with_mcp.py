#!/usr/bin/env python3
"""
第 2 步：把 MCP 工具接进 agent。

要看的重点只有一个：**agent loop 一行都没改。**

本地工具 + MCP 工具混在同一个 tools 列表里，模型完全分不出哪个是哪个 ——
对它来说都是"有个工具叫 xxx，参数是 yyy"。

    先在 config.yaml 里填 api_key，然后：
    python step2_agent_with_mcp.py "七月销售完成目标了吗"
"""
import asyncio, os, subprocess, sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from langchain_core.tools import tool, StructuredTool
from langchain.agents import create_agent

from mcp_config import CFG, build_llm, mcp_servers

HERE = Path(__file__).parent


# ══════════════ 本地工具：进程内的普通函数 ══════════════

@tool
def read_file(path: str) -> str:
    """读取本地文件内容。"""
    p = Path(path)
    return p.read_text(encoding="utf-8") if p.is_file() else f"文件不存在 {path}"


@tool
def bash(command: str) -> str:
    """执行 shell 命令。"""
    r = subprocess.run(command, shell=True, capture_output=True,
                       text=True, timeout=60, cwd=HERE)
    return (r.stdout + r.stderr)[:5000] or "(无输出)"


# ══════════════ MCP 工具：把远端工具包成本地函数 ══════════════

def wrap_mcp_tools(session: ClientSession, tools_meta) -> list:
    """核心的 20 行 —— 把 MCP 工具转成 agent 认得的形式。

    做的事只有一件：为每个远端工具造一个本地函数，
    这个函数被调用时，通过 session 转发给 MCP 服务端执行。
    """
    wrapped = []
    for meta in tools_meta:
        async def call(_name=meta.name, **kwargs):
            result = await session.call_tool(_name, kwargs)
            return "\n".join(c.text for c in result.content if hasattr(c, "text"))

        wrapped.append(StructuredTool(
            name=meta.name,
            description=meta.description,        # ← 服务端给的，你不用写
            args_schema=(getattr(meta, "input_schema", None)
                         or meta.inputSchema),   # ← 服务端给的，你不用写
            coroutine=call,
        ))
    return wrapped


# ══════════════ agent ══════════════

SYSTEM = """你是销售分析助手。

可用工具里，query_sales / get_target 来自公司销售数据库，
read_file / bash 操作本地文件。按需使用，用完直接给结论。"""


async def main(task: str):
    # 从 config.yaml 拿第一个 stdio 服务端的启动方式
    srv = next(iter(mcp_servers().values()))
    params = StdioServerParameters(command=srv["command"], args=srv["args"])

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # 1. 问 MCP 服务端有什么工具
            meta = (await session.list_tools()).tools
            mcp_tools = wrap_mcp_tools(session, meta)

            # 2. 跟本地工具拼在一起 —— 这就是全部的"集成"
            all_tools = [read_file, bash] + mcp_tools

            print("=" * 62)
            print(f"本地工具: {[t.name for t in [read_file, bash]]}")
            print(f"MCP 工具: {[t.name for t in mcp_tools]}  ← 来自另一个进程")
            print(f"交给模型: {[t.name for t in all_tools]}  ← 模型分不出区别")
            print(f"任务: {task}")
            print("=" * 62)

            # 3. agent loop —— 跟没有 MCP 时完全一样
            agent = create_agent(
                model=build_llm(),          # ← 配置从 config.yaml 来
                tools=all_tools,
                system_prompt=SYSTEM,
            )

            local_names = {"read_file", "bash"}
            async for chunk in agent.astream(
                {"messages": [("user", task)]},
                {"recursion_limit": CFG["run"]["max_steps"]},
                stream_mode="updates",
            ):
                for update in chunk.values():
                    if not isinstance(update, dict):
                        continue
                    for msg in update.get("messages", []):
                        if msg.type == "ai":
                            if msg.content:
                                print(f"\n\033[33m模型:\033[0m {msg.content}")
                            for tc in msg.tool_calls or []:
                                where = "本地" if tc["name"] in local_names else "MCP"
                                print(f"  \033[36m[{where}]\033[0m "
                                      f"{tc['name']}({tc['args']})")
                        elif msg.type == "tool":
                            first = str(msg.content).strip().splitlines()[:1]
                            print(f"  \033[90m← {first[0] if first else ''}\033[0m")

    print("\n" + "=" * 62)


if __name__ == "__main__":
    asyncio.run(main(" ".join(sys.argv[1:]) or "七月销售完成目标了吗"))
