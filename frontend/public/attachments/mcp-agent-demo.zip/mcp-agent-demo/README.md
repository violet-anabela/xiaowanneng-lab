# MCP 是怎么接进 agent 的

## 一句话

**MCP 就是"从别的进程拿工具"。** 它替换的不是 agent，是你手写的那些工具函数。

```
没有 MCP：工具 = 你文件里的 Python 函数
有了 MCP：工具 = 另一个进程提供的，通过协议拿到定义、通过协议请求执行
```

**agent loop 完全不变。**

## 跑

```bash
pip install -r requirements.txt
```

**第 1 步：看协议本身，不需要 key、不需要框架、不需要大模型。**

```bash
python step1_raw_client.py
```

**第 2、3 步：需要模型。先在 `config.yaml` 里填 `api_key`。**

```bash
python step3_adapter.py --list      # 只列工具，这一步也不需要 key

python step2_agent_with_mcp.py "七月销售完成目标了吗"   # 手写包装版
python step3_adapter.py "七月销售完成目标了吗"          # 适配器版
```

**第 4、5 步：发布与使用。第 5 步只读公开注册表，不需要 key。**

```bash
python step4_publish_and_use.py            # 打包 → 自检 → 当成已发布的包连上去
python step4_publish_and_use.py --agent    # 再加一步：agent 用这个"已发布"的服务端
python step5_registry.py postgres          # 从使用者视角搜 MCP Registry
```

**所有配置都在 `config.yaml`，不用 export 环境变量。**

## 第 1 步会看到什么

```
① list_tools() —— 问服务端有什么工具

工具名: query_sales
描述:   查询指定月份的销售明细。month 格式 YYYY-MM，例如 2026-07。
参数:   {"properties": {"month": {"type": "string"}}, "required": ["month"]}

② call_tool() —— 让服务端执行一个工具

call_tool('query_sales', month='2026-07') 返回：
2026-07 销售明细：
华东: 22200
华北: 14400
华南: 15200
合计: 51800
```

**全程没有大模型参与。** MCP 协议本身只有两个动作：

| 动作 | 干什么 |
|---|---|
| `list_tools()` | 我这儿有哪些工具、参数长什么样 |
| `call_tool()` | 帮我执行这个工具 |

就这么两个。剩下的全是传输层细节（stdio / HTTP）。

## 第 2 步的关键 20 行

把远端工具包成本地函数：

```python
for meta in tools_meta:
    async def call(_name=meta.name, **kwargs):
        result = await session.call_tool(_name, kwargs)   # ← 转发给 MCP 服务端
        return "\n".join(c.text for c in result.content)

    wrapped.append(StructuredTool(
        name=meta.name,
        description=meta.description,      # ← 服务端给的，你不用写
        args_schema=meta.input_schema,     # ← 服务端给的，你不用写
        coroutine=call,
    ))
```

然后拼在一起：

```python
all_tools = [read_file, bash] + mcp_tools    # ← 这就是全部的"集成"
agent = create_agent(model=..., tools=all_tools, system_prompt=...)
```

**模型分不出哪个是本地的、哪个来自 MCP。** 对它来说都是
"有个工具叫 xxx，参数是 yyy"。

## 那 MCP 到底解决了什么

**没有 MCP 你也能写 `query_sales` 这个函数** —— 自己连数据库就行。
MCP 的价值在别处：

| | 手写工具 | MCP |
|---|---|---|
| 谁写的 | 你 | 服务提供方（GitHub、Slack、数据库厂商…） |
| 装依赖 | 你的进程里 | 服务端进程里，跟你隔离 |
| 换 agent | 得重写一遍 | 换个 client 连上就行 |
| 权限/凭据 | 你的代码持有 | 服务端持有 |
| 工具定义 | 你手写 schema | `list_tools()` 自动拿 |

**一句话：MCP 让"提供工具"和"使用工具"解耦了。** GitHub 写一个 MCP 服务端，
所有 agent 都能用；否则每个 agent 作者都得自己封装一遍 GitHub API。

## skill 和 MCP 的区别

这两个经常被搞混，其实一个补能力、一个补知识：

| | MCP | Skill |
|---|---|---|
| 给 agent 的是 | **能力** —— 能碰到什么 | **知识** —— 该怎么做 |
| 形态 | 独立进程 + 协议 | 一个文件夹 + 一个 md |
| 进上下文的 | 工具定义（schema） | SKILL.md 正文 |
| 解决 | agent 够不着的东西 | agent 够得着但不知道怎么做的东西 |

举例：

- **MCP** 让 agent 能查你们公司的销售库
- **Skill** 告诉 agent「做月报要先查目标、再算完成率、金额写成 ¥1,234.00」

**两者常一起用。** SKILL.md 里完全可以写"用 query_sales 工具取数据" ——
知识指挥能力。

## 怎么挂外部现成的 MCP

**往 `config.yaml` 的 `mcp_servers` 里加一个条目，不改任何代码。**

```yaml
mcp_servers:
  sales-db:                         # 本 demo 自带的
    command: python
    args: ["sales_server.py"]
    transport: stdio

  github:                           # 外部的，需要凭据
    command: npx
    args: ["-y", "@modelcontextprotocol/server-github"]
    transport: stdio
    env:
      GITHUB_PERSONAL_ACCESS_TOKEN: "${GITHUB_TOKEN}"

  remote:                           # 远程服务端，填 URL
    url: "https://mcp.example.com/mcp"
    transport: streamable_http
```

**凭据用 `${ENV_VAR}` 占位**，读取时自动从环境变量展开 —— 别把 token
写进配置文件然后提交到 git。

`config.yaml` 里已经放好了这三种写法的示例，都以下划线开头（会被跳过），
去掉下划线即生效。

## MCP Registry 是什么

**一句话：它是黄页，不是应用商店。**

跑 `python step5_registry.py postgres` 就能看清楚 —— 注册表返回的每条记录只有
名字、版本、包坐标（"这个东西在 PyPI 上叫 postgres-aiops"）、要哪些环境变量。
**没有一个字节的实现代码。**

```
你搜注册表      →  registry.modelcontextprotocol.io   给你一个包名 / 一个 URL
你真正下载      →  PyPI / npm / 对方的 HTTPS 服务      ← 代码从这儿来
```

所以它解决的是**发现问题**，不是分发问题：以前找 MCP 服务端只能翻 GitHub
README 和各种野生列表，现在 Claude Code、Cursor 这些客户端直接把它的搜索接
进了界面。

它做的事就三件：

| 做 | 不做 |
|---|---|
| 记录 name / version / 包坐标 / 传输方式 / 需要哪些变量 | 托管代码 |
| 验证命名空间归你（GitHub 登录或 DNS） | 安全审核、恶意代码扫描 |
| 提供一个公开只读 JSON API | 保证服务端能跑、质量达标 |

第二行反过来对使用者也成立：**上架不等于安全**，装外部 MCP 前看清是谁发的。

API 本身没有 SDK、不要 key，curl 就能用：

```bash
curl "https://registry.modelcontextprotocol.io/v0.1/servers?search=postgres&limit=3"
```

## 怎么把自己的 MCP 发布出去

见 `PUBLISH.md`，可运行的完整例子是 `step4_publish_and_use.py` + `publish/`。

真发布的 `uv publish` / `mcp-publisher publish` 是不可逆的公开动作，所以
step4 只做到"本地彩排"：**构建产物、自检逻辑、连接方式都跟真发布后一模一样**，
唯独没推到公网。

```
① 自检   README 的 mcp-name 标记 vs server.json 的 name（对不上直接被拒）
         三处版本号是否一致
② 构建   uv build → dist/mcp_sales_db-0.1.0-py3-none-any.whl
③ 使用   uvx --from <wheel> mcp-sales-db      ← 发布后就是 uvx mcp-sales-db
         list_tools() / call_tool() 正常 → 这个包别人拿到手就能用
④ 上架   uv publish + mcp-publisher publish   ← 这步留给你自己跑
```

## 文件

```
sales_server.py            MCP 服务端，两个工具（假装是公司数据库）
                           支持 stdio 和 HTTP 两种传输，靠环境变量切
step0_by_hand.py           手搓 stdio 客户端，零依赖 ← 先看这个
step0b_remote_by_hand.py   手搓 HTTP 客户端，对照组
step1_raw_client.py        用 mcp 库，省掉握手细节
step2_agent_with_mcp.py    手写包装接进 agent，看清机制
step3_adapter.py           官方适配器版，配置驱动 ← 实际用法
step4_publish_and_use.py   发布彩排：打包 → 自检 → 当成已发布的包用
step5_registry.py          查 MCP Registry，看清它只存元数据
mcp_tap.py                 透明代理，把两个方向的报文记进 mcp_trace.log
config.yaml                所有配置：模型 + MCP 服务端 + 运行参数
mcp_config.py              读配置的公共模块
PUBLISH.md                 发布指南

publish/                   可直接构建发布的包
  pyproject.toml           [project.scripts] 决定别人敲什么命令
  README.md                PyPI 归属验证标记 mcp-name 藏在这里
  server.json              上架用的元数据
  src/mcp_sales_db/server.py
```

## 跨平台

`config.yaml` 里 `command` 写 `python` 还是 `python3` 都行 —— 读取时会
自动换成 `sys.executable`（正在跑脚本的那个解释器，**含 venv**）。

```yaml
command: python        # 你写这个
                       # ↓ 实际用这个
                       # /Users/you/project/.venv/bin/python
```

理由：**macOS 没有 `python`，Windows 没有 `python3`**，而 venv 里两个
可能都不指向你想要的解释器。`sys.executable` 是唯一永远正确的答案，
顺带解决了"agent 在 venv 里、子进程却用系统 Python 结果 import 失败"这个经典坑。

`args` 里的 `.py` 相对路径也会自动转成绝对路径 —— MCP 客户端启动子进程时
**工作目录不保证是项目目录**，相对路径基本不会解析成你想的样子。

## 版本坑

MCP Python SDK 1.x 和 2.0 有 breaking change，本 demo 已兼容两者：

| | 1.x | 2.0 |
|---|---|---|
| 服务端类 | `mcp.server.fastmcp.FastMCP` | `mcp.server.MCPServer` |
| schema 字段 | `tool.inputSchema` | `tool.input_schema` |

**另外注意**：`langchain-mcp-adapters` 目前会把 `mcp` 锁在 1.x，
装了它之后 2.0 的 API 就没了。所以代码里用 try/except 兼容两边最稳。
