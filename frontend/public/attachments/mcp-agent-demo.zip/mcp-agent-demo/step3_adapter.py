#!/usr/bin/env python3
"""
第 3 步：用官方适配器 + 配置文件挂载多个 MCP 服务端。

step2 里那 20 行手写包装，适配器一行搞定。
加一个外部 MCP 服务端 = 往 config.yaml 的 mcp_servers 里加一个条目，
不用改这个文件。

    pip install langchain-mcp-adapters
    python step3_adapter.py --list        # 只列工具，不需要 api_key
    python step3_adapter.py "七月完成目标了吗"
"""
import asyncio, sys

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent

from mcp_config import CFG, build_llm, mcp_servers


async def main(task: str, list_only: bool):
    servers = mcp_servers()
    print(f"config.yaml 里的 MCP 服务端: {list(servers)}\n")

    client = MultiServerMCPClient(servers)
    tools = await client.get_tools()        # ← 替代整个 wrap_mcp_tools
    for t in tools:
        print(f"  {t.name:20} {(t.description or '')[:50]}")

    if list_only:
        print(f"\n共 {len(tools)} 个工具。给个任务参数就能实际跑。")
        return

    agent = create_agent(
        model=build_llm(),
        tools=tools,                       # 本地工具直接 + 上去即可
        system_prompt="你是销售分析助手。按需使用工具，用完直接给结论。",
    )
    result = await agent.ainvoke(
        {"messages": [("user", task)]},
        {"recursion_limit": CFG["run"]["max_steps"]},
    )
    print("\n" + result["messages"][-1].content)


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    asyncio.run(main(" ".join(args) or "七月销售完成目标了吗",
                     list_only="--list" in sys.argv or not args))
