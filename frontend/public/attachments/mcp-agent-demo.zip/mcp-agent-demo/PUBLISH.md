# 发布自己的 MCP，让外部能用

先说清一件事：**MCP Registry 不托管你的代码，它只存元数据。**
真正的分发靠 PyPI / npm（本地型），或者你自己的服务器（远程型）。

所以"发布"分两条路。想直接看跑得通的例子，先跑这个：

```bash
python step4_publish_and_use.py --agent    # 构建 → 自检 → 当成已发布的包连上去 → agent 用它
python step5_registry.py postgres          # 从使用者视角搜注册表
```

`step4` 做完了除"推到公网"之外的每一步，产出物和连接方式跟真发布后一模一样。

---

## 路线 A：本地型（别人在自己机器上跑你的包）

用户装上包，agent 把它当子进程启动，走 stdio。适合要访问用户本地资源、
或者凭据必须留在用户手里的场景。

`publish/` 就是这么一个能直接构建的包：

```
publish/
  pyproject.toml              [project.scripts] 决定别人敲什么命令
  README.md                   ← 归属验证标记藏在这里
  server.json                 上架用的元数据
  src/mcp_sales_db/server.py  跟根目录 sales_server.py 同一个服务端
```

### 1. 先发到包仓库

**关键一步**：得让注册表确认这个包确实是你的。不同仓库查的地方不一样：

| 包类型 | 标记放哪 | 长什么样 |
|---|---|---|
| **PyPI** | 包的 **README**（会成为 PyPI 上的项目描述） | `<!-- mcp-name: io.github.你/sales-db -->` |
| **npm** | `package.json` 的字段 | `"mcpName": "io.github.你/sales-db"` |
| NuGet | 包 README | 同 PyPI |
| OCI/Docker | Dockerfile 的 LABEL | `LABEL io.modelcontextprotocol.server.name="..."` |

PyPI 这条经常被写错成"在 pyproject 里加 mcpName 字段"——**没有这个字段**，
注册表是去抓 PyPI 页面上的项目描述文本，找 `mcp-name:` 这个字符串。
写成 HTML 注释也认，只是不弄脏 README 观感。值必须跟 `server.json` 的
`name` 一字不差，否则发布被拒。

`publish/pyproject.toml` 里那行 `readme = "README.md"` 就是把标记送上 PyPI 的通道，
删了它验证就过不了。

顺带，`[project.scripts]` 决定别人装完敲什么：

```toml
[project.scripts]
mcp-sales-db = "mcp_sales_db.server:main"    # → 用户 `uvx mcp-sales-db`
```

没有这行，用户就得自己去 site-packages 里找 .py 文件，等于没法用。

```bash
cd publish
uv build            # 产出 dist/*.whl
uv publish          # 或 python -m build && twine upload dist/*
```

### 2. 写 server.json

见 `publish/server.json`。名字是反向 DNS 格式：

```
io.github.alice/weather-server      ← GitHub 用户，用 GitHub 登录即可验证
com.yourcompany/internal-tool       ← 自有域名，需要 DNS 验证
```

两条硬规则：

- **版本号三处必须一致**：`server.json` 顶层 `version`、`packages[].version`、
  包本身的版本。对不上直接报校验错。
- **凭据一律写成 secret 输入项，不要填真值**（`"isSecret": true`）。

schema 用当前这版（旧的 `2025-09-29` 已经过时）：

```json
"$schema": "https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json"
```

`step4_publish_and_use.py` 的第 1 步就是在本地把这两条规则先查一遍，
省得推到一半被拒。

### 3. 登录并发布

```bash
mcp-publisher init            # 扫描项目生成 server.json 模板
mcp-publisher login github    # device code 流程，浏览器授权
mcp-publisher validate        # 只校验不提交
mcp-publisher publish
```

`init` 生成的是模板，**发布前逐字过一遍** —— 有人反馈它会把 `.env`
里的老环境变量也扒出来写进去。

验证：

```bash
curl "https://registry.modelcontextprotocol.io/v0.1/servers?search=io.github.你的用户名/sales-db"
```

### 4. 别人怎么用

```bash
claude mcp add --transport stdio sales-db -- uvx mcp-sales-db
```

或者在 Claude Code / Cursor 里直接搜 registry —— 这些客户端已经把
registry 搜索集成进界面了，所以上架的实际意义是**出现在用户已经会去找的地方**。

---

## 路线 B：远程型（你部署成服务，别人填 URL）

适合服务需要你自己的基础设施、或者你想集中控制版本和权限。

### 1. 同一份代码换个传输方式

`sales_server.py` 和 `publish/src/mcp_sales_db/server.py` 都已经支持了：

```bash
MCP_TRANSPORT=http python sales_server.py     # 起在 127.0.0.1:8000/mcp
```

靠环境变量切换，**不用维护两个版本**。部署到任何能跑 HTTP 的地方即可
（容器、Cloud Run、Azure Functions…）。

### 2. server.json 换成 remotes

```json
{
  "name": "com.yourcompany/sales-db",
  "version": "1.0.0",
  "remotes": [
    { "type": "streamable-http", "url": "https://mcp.yourcompany.com/mcp" }
  ]
}
```

远程型**不需要包归属验证**（没有包），但**自有域名要做 DNS 验证**
（用 `io.github.*` 前缀就只需 GitHub 登录）。

### 3. 别人怎么用

```bash
claude mcp add --transport http sales-db https://mcp.yourcompany.com/mcp
```

远程型天然支持 OAuth，用户授权比塞 token 体验好。

---

## 传输方式怎么选

| | 用在哪 |
|---|---|
| **stdio** | 本地服务端。子进程 + 标准输入输出 |
| **streamable-http** | 远程服务端。**目前官方推荐** |
| **SSE** | 老的远程方案，已弃用。老服务还在跑，新项目别用 |

---

## 五个高频坑

1. **stdio 模式下 print 到标准输出 = 协议流损坏。** 那是 JSON-RPC 通道，
   一行多余输出就崩。日志往 stderr 或文件写。第三方库里的 debug print
   也要查。
2. **配置里用相对路径、或者 `command` 写死 `python`。** 客户端启动你的服务端时
   工作目录不可预测；而 macOS 没有 `python`、Windows 没有 `python3`。
   给别人的安装说明里，解释器用 `uvx` / `npx` 这种包管理器入口，
   别让用户去猜写哪个。
3. **归属标记和 `server.json` 的 name 不一致，或版本号三处对不上** → 发布被拒。
4. **把真 token 写进 server.json / README / 发布物。** 一律用 secret 输入项。
5. **上架 ≠ 安全审核。** registry 只证明"元数据和命名空间归你"，
   不做恶意代码扫描。这话反过来对使用者也成立 —— 装外部 MCP 前看清是谁发的。
