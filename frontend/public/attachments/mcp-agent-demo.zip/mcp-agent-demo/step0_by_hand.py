#!/usr/bin/env python3
"""
用别人的 MCP —— 不用任何 MCP 库，纯标准库版。

目的是看清"用一个 MCP"到底是什么操作：
    启动一个子进程 → 往它 stdin 写 JSON → 从它 stdout 读 JSON

跑：python step0_by_hand.py
"""
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).parent

# ── 1. 启动它。这就是配置文件里 command / args 那两行的真身 ──────────
proc = subprocess.Popen(
    ["npx", "-y", "@modelcontextprotocol/server-filesystem", str(HERE / "demo_files")],
    stdin=subprocess.PIPE,      # 我写给它
    stdout=subprocess.PIPE,     # 它回给我   ← 这两根管子就是 "stdio"
    stderr=subprocess.DEVNULL,  # 它的日志，跟协议无关，丢掉
    text=True,
)


def send(obj):
    """一行一个 JSON，写进去。"""
    proc.stdin.write(json.dumps(obj) + "\n")
    proc.stdin.flush()


def recv():
    """读回一行，解析成 dict。"""
    return json.loads(proc.stdout.readline())


# ── 2. 握手。固定套路，抄就完了 ──────────────────────────────────
send({"jsonrpc": "2.0", "id": 1, "method": "initialize",
      "params": {"protocolVersion": "2025-06-18", "capabilities": {},
                 "clientInfo": {"name": "手写客户端", "version": "0"}}})
print("① 握手 →", recv()["result"]["serverInfo"])

send({"jsonrpc": "2.0", "method": "notifications/initialized"})   # 通知，没有回复


# ── 3. 问它有什么工具 ──────────────────────────────────────────
send({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
tools = recv()["result"]["tools"]
print(f"\n② 它有 {len(tools)} 个工具:", [t["name"] for t in tools][:5], "...")


# ── 4. 让它干活 ───────────────────────────────────────────────
send({"jsonrpc": "2.0", "id": 3, "method": "tools/call",
      "params": {"name": "read_text_file",
                 "arguments": {"path": str(HERE / "demo_files" / "八月周报.md")}}})
print("\n③ 调用 read_text_file →")
print(recv()["result"]["content"][0]["text"])

proc.terminate()
print("④ 关掉子进程。完事。")
