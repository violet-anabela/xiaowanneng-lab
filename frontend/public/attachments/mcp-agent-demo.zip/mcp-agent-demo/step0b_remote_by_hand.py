#!/usr/bin/env python3
"""
用远程型 MCP —— 同样不用任何 MCP 库，纯标准库版。

跟 step0_by_hand.py 是对照组：**发的 JSON 一模一样**，
区别只有一条 —— 那边写进子进程的 stdin，这边 POST 到一个 URL。

这里连的是 RideDesk 的公开文档服务端（免密钥、只读），
从 MCP Registry 上搜到的：app.ridedesk/docs

跑：python step0b_remote_by_hand.py
"""
import json
import urllib.request

URL = "https://ridedesk.app/api/mcp"


def rpc(method, params=None, _id=[0]):
    """发一个 JSON-RPC 请求，拿回结果。stdio 版是写管道，这里是 POST。"""
    _id[0] += 1
    body = {"jsonrpc": "2.0", "id": _id[0], "method": method}
    if params is not None:
        body["params"] = params

    req = urllib.request.Request(
        URL,
        data=json.dumps(body).encode(),
        headers={
            "Content-Type": "application/json",
            # streamable-http 允许服务端用 SSE 流式回，所以两种都要声明能接
            "Accept": "application/json, text/event-stream",
            # urllib 默认 UA 会被不少 CDN 挡掉（403），随便给个正常的
            "User-Agent": "mcp-demo/0.1",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read())["result"]


# ── 1. 握手。跟 stdio 版逐字一样 ────────────────────────────────
info = rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                          "clientInfo": {"name": "手写客户端", "version": "0"}})
print("① 握手 →", info["serverInfo"])

# ── 2. 问它有什么工具 ──────────────────────────────────────────
tools = rpc("tools/list")["tools"]
print(f"\n② 它有 {len(tools)} 个工具:", [t["name"] for t in tools])

# ── 3. 让它干活 ───────────────────────────────────────────────
out = rpc("tools/call", {"name": "list_docs", "arguments": {}})
print("\n③ 调用 list_docs →")
print(out["content"][0]["text"][:400])

print("\n④ 没有进程要关 —— 它跑在别人服务器上，我们只是发了三个 HTTP 请求。")
