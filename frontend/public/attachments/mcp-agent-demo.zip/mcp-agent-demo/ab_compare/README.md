# 同一件事，两种实现

同一个「查销售、判断有没有达标」的 agent，写两遍：

```
version_a.py           普通工具版。一个文件，函数就在本进程里
version_b_server.py    MCP 版之一：服务端。函数原封不动搬过来
version_b_agent.py     MCP 版之二：agent 侧
```

跑法（先 `export ZHIPU_API_KEY=...`）：

```bash
python version_a.py           # 普通工具版
python version_b_agent.py     # MCP 版（它会自己把 server 当子进程拉起来）
```

两个版本的输出是同一个结论：七月 51,800 / 目标 50,000，达成率 103.6%。

看 diff：

```bash
diff version_a.py version_b_server.py    # 业务逻辑：只多了 @server.tool()
```
