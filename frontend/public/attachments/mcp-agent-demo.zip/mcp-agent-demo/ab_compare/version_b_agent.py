"""版本 B 之二：agent 侧。跟版本 A 相比只有 tools= 那一处不一样。"""
import asyncio
import os
import sys
from pathlib import Path

from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import ChatOpenAI

model = ChatOpenAI(
    model="glm-5.2",
    api_key=os.environ["ZHIPU_API_KEY"],
    base_url="https://open.bigmodel.cn/api/paas/v4/",
    temperature=0,
)


async def main():
    client = MultiServerMCPClient({
        "sales-db": {
            "command": sys.executable,
            "args": [str(Path(__file__).with_name("version_b_server.py"))],
            "transport": "stdio",
        }
    })
    tools = await client.get_tools()           # ← 唯一的区别：工具从别的进程要来
    print("从 MCP 拿到的工具:", [t.name for t in tools], "\n")

    agent = create_agent(
        model=model,
        tools=tools,                           # ← 拿到之后用法跟本地函数完全一样
        system_prompt="你是销售分析助手。按需使用工具，用完直接给结论。",
    )
    result = await agent.ainvoke({"messages": [("user", "七月完成目标了吗")]})
    print(result["messages"][-1].content)


asyncio.run(main())
