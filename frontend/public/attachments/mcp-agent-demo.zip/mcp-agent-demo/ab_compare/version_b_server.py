"""版本 B 之一：MCP 服务端。函数原封不动搬过来，只多了个装饰器。"""
from mcp.server.fastmcp import FastMCP

server = FastMCP("sales-db")

_DB = {"2026-07": {"华东": 22200, "华北": 14400, "华南": 15200}}
_TARGETS = {"2026-07": 50000}


@server.tool()                                 # ← 只多了这一行
def query_sales(month: str) -> str:
    """查询指定月份的销售明细。month 格式 YYYY-MM，例如 2026-07。"""
    rows = _DB.get(month)
    if not rows:
        return f"没有 {month} 的数据。可用月份：2026-07"
    detail = "、".join(f"{k} {v}" for k, v in rows.items())
    return f"{month} 销售明细：{detail}，合计 {sum(rows.values())}"


@server.tool()                                 # ← 只多了这一行
def get_target(month: str) -> str:
    """查询指定月份的销售目标。month 格式 YYYY-MM。"""
    t = _TARGETS.get(month)
    return f"{month} 目标: {t}" if t else f"没有 {month} 的目标数据"


if __name__ == "__main__":
    server.run(transport="stdio")               # ← 和这一行
