"""版本 A：普通工具。一个文件，函数就在本进程里。"""
import os

from langchain.agents import create_agent
from langchain_openai import ChatOpenAI

_DB = {"2026-07": {"华东": 22200, "华北": 14400, "华南": 15200}}
_TARGETS = {"2026-07": 50000}


def query_sales(month: str) -> str:
    """查询指定月份的销售明细。month 格式 YYYY-MM，例如 2026-07。"""
    rows = _DB.get(month)
    if not rows:
        return f"没有 {month} 的数据。可用月份：2026-07"
    detail = "、".join(f"{k} {v}" for k, v in rows.items())
    return f"{month} 销售明细：{detail}，合计 {sum(rows.values())}"


def get_target(month: str) -> str:
    """查询指定月份的销售目标。month 格式 YYYY-MM。"""
    t = _TARGETS.get(month)
    return f"{month} 目标: {t}" if t else f"没有 {month} 的目标数据"


model = ChatOpenAI(
    model="glm-5.2",
    api_key=os.environ["ZHIPU_API_KEY"],
    base_url="https://open.bigmodel.cn/api/paas/v4/",
    temperature=0,
)

agent = create_agent(
    model=model,
    tools=[query_sales, get_target],          # ← 本地函数，直接塞进去
    system_prompt="你是销售分析助手。按需使用工具，用完直接给结论。",
)

result = agent.invoke({"messages": [("user", "七月完成目标了吗")]})
print(result["messages"][-1].content)
