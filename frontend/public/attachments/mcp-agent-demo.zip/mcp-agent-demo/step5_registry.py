#!/usr/bin/env python3
"""
第 5 步：从使用者视角看 MCP Registry —— 搜、看清楚、拼出安装命令。

注册表是个**纯元数据的 JSON API**，没有 SDK、不需要 key、不返回任何代码。
搜到之后真正的下载还是走 PyPI / npm / 你自己的 HTTPS 服务。

跑：
    python step5_registry.py            # 看默认几条，理解返回结构
    python step5_registry.py postgres   # 搜关键词
"""
import json
import sys
import urllib.parse
import urllib.request

API = "https://registry.modelcontextprotocol.io/v0.1/servers"


def fetch(search: str | None, limit: int = 5) -> list[dict]:
    q = {"limit": str(limit)}
    if search:
        q["search"] = search
    with urllib.request.urlopen(f"{API}?{urllib.parse.urlencode(q)}", timeout=20) as r:
        return json.load(r)["servers"]


def _slug(name: str) -> str:
    """io.github.someone/sqlite → sqlite，拿来当配置里的键名。"""
    return name.rsplit("/", 1)[-1]


def describe(entry: dict) -> None:
    s = entry["server"]
    official = entry.get("_meta", {}).get("io.modelcontextprotocol.registry/official", {})

    print(f"\n{'─' * 64}")
    print(f"name        {s['name']}")
    print(f"version     {s['version']}   （{official.get('status', '?')}"
          f"{'，最新' if official.get('isLatest') else ''}）")
    print(f"description {s.get('description', '')[:70]}")

    # 一个条目要么给 packages（本地跑），要么给 remotes（连过去），也可能都给
    #
    # 下面打印的是 config.yaml 里该怎么写。注册表本身不规定配置格式 ——
    # 每个客户端的配置文件长得都不一样（Claude Desktop 用 json、Cursor 用
    # .cursor/mcp.json、本 demo 用 yaml），但字段永远是这三个：
    # 怎么启动（command+args）或连哪（url），加上 transport。
    local = _slug(s["name"])

    for p in s.get("packages", []):
        reg, ident = p["registryType"], p["identifier"]
        print(f"\n  📦 本地型 · {reg} · {ident}=={p.get('version', '?')}")
        cmd, args = {
            "pypi": ("uvx", [ident]),
            "npm": ("npx", ["-y", ident]),
            "oci": ("docker", ["run", "-i", "--rm", ident]),
        }.get(reg, ("?", [ident]))
        print(f"     命令行试跑   {cmd} {' '.join(args)}")
        print(f"     配置里写：")
        print(f"       {local}:")
        print(f"         command: {cmd}")
        print(f"         args: {json.dumps(args)}")
        print(f"         transport: stdio")
        env = p.get("environmentVariables", [])
        if env:
            print(f"         env:")
            for e in env:
                mark = "  # 必填" if e.get("isRequired") else ""
                mark += "，机密别写死" if e.get("isSecret") else ""
                print(f"           {e['name']}: \"${{{e['name']}}}\"{mark}")

    for r in s.get("remotes", []):
        # 注册表里写 streamable-http（连字符），配置里要写 streamable_http（下划线）
        tr = r["type"].replace("-", "_")
        print(f"\n  🌐 远程型 · {r['type']}    不用装任何东西")
        print(f"     配置里写：")
        print(f"       {local}:")
        print(f"         url: \"{r['url']}\"")
        print(f"         transport: {tr}")


def main() -> None:
    kw = " ".join(sys.argv[1:]) or None
    print(f"GET {API}?search={kw or '(不限)'}")
    servers = fetch(kw)
    if not servers:
        print("没搜到。注册表还在 preview，收录量有限。")
        return
    for entry in servers:
        describe(entry)

    print(f"\n{'─' * 64}")
    print("注意上面每一条：只有名字、版本、包坐标、需要哪些环境变量。")
    print("没有一个字节的实现代码 —— 那些在 PyPI / npm / 对方服务器上。")
    print("注册表干的是「黄页」的活，不是「应用商店」。")
    print("\n上面的 yaml 直接粘到 config.yaml 的 mcp_servers: 下面就能用，")
    print("跑 `python step3_adapter.py --list` 验证工具有没有出来。")


if __name__ == "__main__":
    main()
