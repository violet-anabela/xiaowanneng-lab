"""读 config.yaml，三个脚本共用。"""
import json, os, re, sys
from pathlib import Path

import yaml

HERE = Path(__file__).parent
CFG = yaml.safe_load((HERE / "config.yaml").read_text(encoding="utf-8"))


def llm_config() -> dict:
    c = CFG["llm"]
    if not c.get("api_key") or "填" in str(c["api_key"]):
        sys.exit("请先在 config.yaml 里填上 api_key")
    return c


def _abs(arg):
    """把配置里的相对路径参数换成绝对路径，其余原样返回。"""
    if not isinstance(arg, str) or Path(arg).is_absolute():
        return arg
    if arg.endswith(".py") or arg.startswith(("./", "../")):
        return str((HERE / arg).resolve())
    return arg


def mcp_servers() -> dict:
    """展开 ${ENV_VAR}、跳过下划线条目、修正 python 解释器。"""
    servers = CFG.get("mcp_servers") or {}
    text = json.dumps(servers)
    text = re.sub(r"\$\{(\w+)\}", lambda m: os.environ.get(m.group(1), ""), text)
    out = {k: v for k, v in json.loads(text).items() if not k.startswith("_")}

    for name, cfg in out.items():
        # python / python3 一律换成当前解释器的绝对路径。
        #   macOS 没有 python，Windows 没有 python3，venv 里两个都可能不对。
        #   sys.executable 就是正在跑本文件的那个解释器 —— 永远是对的。
        if cfg.get("command") in ("python", "python3", "py"):
            cfg["command"] = sys.executable

        # 相对路径换成绝对路径。
        #   MCP 客户端启动子进程时工作目录不保证是本目录，
        #   ./demo_files 这种十有八九解析不到你想的地方。
        #   规则：.py 结尾的、或者以 ./ ../ 开头的，都按"相对本文件目录"展开。
        #   注意只在本来就有 args 时才动它 —— 远程型条目没有 args，
        #   凭空塞一个空列表进去，streamable_http 那条路会因为多了个
        #   不认识的关键字参数直接 TypeError。
        if "args" in cfg:
            cfg["args"] = [_abs(a) for a in cfg["args"]]
    return out


def build_llm():
    from langchain_openai import ChatOpenAI
    c = llm_config()
    return ChatOpenAI(model=c["model"], api_key=c["api_key"],
                      base_url=c.get("base_url") or None,
                      temperature=c.get("temperature", 0))
