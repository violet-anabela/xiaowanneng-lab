#!/usr/bin/env python3
"""
最小 MCP 服务端。

它是一个**独立进程**，通过 stdio 跟 agent 说话。
里面的工具是 agent 本地做不到的事 —— 查数据库、调外部 API。

两种跑法：
    python sales_server.py                      # stdio，等 agent 来启动它
    MCP_TRANSPORT=http python sales_server.py   # HTTP 服务，别人填 URL 来连

注意：stdio 模式下**绝对不能 print 到标准输出** —— 那是协议通道，
一行多余的输出就会把 JSON-RPC 流搞坏。日志往 stderr 写。
"""
# SDK 1.x 叫 FastMCP，2.0 改名 MCPServer。兼容两种，装到哪个版本都能跑
try:
    from mcp.server import MCPServer as _Server          # SDK 2.x
except ImportError:
    from mcp.server.fastmcp import FastMCP as _Server    # SDK 1.x

server = _Server("sales-db")

# 假装这是公司数据库
_DB = [
    {"month": "2026-06", "region": "华东", "amount": 19800},
    {"month": "2026-06", "region": "华北", "amount": 16200},
    {"month": "2026-06", "region": "华南", "amount": 13500},
    {"month": "2026-07", "region": "华东", "amount": 22200},
    {"month": "2026-07", "region": "华北", "amount": 14400},
    {"month": "2026-07", "region": "华南", "amount": 15200},
]

_TARGETS = {"2026-06": 45000, "2026-07": 50000}


@server.tool()
def query_sales(month: str) -> str:
    """查询指定月份的销售明细。month 格式 YYYY-MM，例如 2026-07。"""
    rows = [r for r in _DB if r["month"] == month]
    if not rows:
        return f"没有 {month} 的数据。可用月份：2026-06、2026-07"
    lines = [f"{r['region']}: {r['amount']}" for r in rows]
    total = sum(r["amount"] for r in rows)
    return f"{month} 销售明细：\n" + "\n".join(lines) + f"\n合计: {total}"


@server.tool()
def get_target(month: str) -> str:
    """查询指定月份的销售目标。month 格式 YYYY-MM。"""
    t = _TARGETS.get(month)
    return f"{month} 目标: {t}" if t else f"没有 {month} 的目标数据"


if __name__ == "__main__":
    # 同一份代码，两种传输方式 —— 靠环境变量切换，不用维护两个版本
    #   stdio : 别人在自己机器上跑你的包（子进程，读写标准输入输出）
    #   http  : 你部署成服务，别人填个 URL 就能连
    import os
    transport = os.environ.get("MCP_TRANSPORT", "stdio")
    if transport == "http":
        server.run(transport="streamable-http")   # 默认 127.0.0.1:8000/mcp
    else:
        server.run(transport="stdio")
