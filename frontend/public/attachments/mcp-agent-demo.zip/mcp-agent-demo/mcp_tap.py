#!/usr/bin/env python3
"""
窃听器：夹在客户端和 MCP 服务端中间，把两个方向的报文原样记下来。

它本身也是一个"服务端"（对客户端而言），同时又是一个"客户端"（对真服务端而言），
中间什么都不改，只是抄一份到日志里。

用法 —— 在 config.yaml 里把原来的启动命令包一层：

    sales-db:
      command: python
      args: ["mcp_tap.py", "sales_server.py"]     # ← 原来是 ["sales_server.py"]
      transport: stdio

日志写到 mcp_trace.log。注意日志绝不能写 stdout —— 那是协议通道。
"""
import os
import subprocess
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path

LOG = Path(__file__).parent / "mcp_trace.log"
_lock = threading.Lock()


# 同一次 agent 运行里可能起好几个会话（每个会话一个本进程），
# 带上 pid 才分得清哪条报文属于哪个会话。
SESSION = f"会话{os.getpid() % 1000:03d}"


def log(direction: str, line: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S.%f")[:-3]
    with _lock:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"{ts} {SESSION} {direction} {line.rstrip()}\n")


def pump(src, dst, direction: str) -> None:
    """一行一行搬运，顺手抄一份。"""
    for line in src:
        log(direction, line)
        dst.write(line)
        dst.flush()
    dst.close()


# 把真正的服务端当子进程拉起来（argv[1:] 就是原来的启动命令）
real = subprocess.Popen(
    [sys.executable, *sys.argv[1:]],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1,
)

threads = [
    # 客户端 → 我 → 真服务端
    threading.Thread(target=pump, args=(sys.stdin, real.stdin, "→ 请求 "), daemon=True),
    # 真服务端 → 我 → 客户端
    threading.Thread(target=pump, args=(real.stdout, sys.stdout, "← 回复 "), daemon=True),
]
for t in threads:
    t.start()
real.wait()
