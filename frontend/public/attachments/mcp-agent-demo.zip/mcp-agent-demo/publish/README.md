# mcp-sales-db

查询公司销售明细与目标完成情况的 MCP 服务端。

<!-- mcp-name: io.github.你的用户名/sales-db -->

上面这行 HTML 注释**就是 PyPI 的归属验证标记**。注册表会去 PyPI 上抓这个包的
描述（也就是本 README），找 `mcp-name: <服务端名>`，值必须跟 `server.json`
里的 `name` 一字不差，否则 `mcp-publisher publish` 直接拒。

注释形式和明文形式都认，用注释只是为了不弄脏 README 的观感。

## 装 & 用

```bash
uvx mcp-sales-db          # 不装到全局，用完即走
```

接进 Claude Code：

```bash
claude mcp add --transport stdio sales-db -- uvx mcp-sales-db
```

## 工具

| 工具 | 干什么 |
|---|---|
| `query_sales(month)` | 查某月各区域销售明细，month 格式 `YYYY-MM` |
| `get_target(month)`  | 查某月销售目标 |
