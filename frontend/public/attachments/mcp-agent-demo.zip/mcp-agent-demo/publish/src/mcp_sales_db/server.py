#!/usr/bin/env python3
"""跟根目录 sales_server.py 是同一个服务端，只是搬进了包里。

差别只有两点，但都是"能不能发布"的分水岭：

1. 逻辑收在 main() 里，pyproject.toml 的 [project.scripts] 指向它
   —— 别人装完包就有 `mcp-sales-db` 这个命令，不用知道 .py 文件在哪。
2. 不依赖当前工作目录、不依赖同级文件 —— 装到别人机器上任意位置都能跑。
"""

import os

# SDK 1.x 叫 FastMCP，2.0 改名 MCPServer。兼容两种，装到哪个版本都能跑
try:
    from mcp.server import MCPServer as _Server          # SDK 2.x
except ImportError:
    from mcp.server.fastmcp import FastMCP as _Server    # SDK 1.x

server = _Server("sales-db")

# 假装这是公司数据库
_DB = [
    {"month": "2026-06", "region": "华东", "amount": 19800},
    {"month": "2026-06", "region": "华北", "amount": 16200},
    {"month": "2026-06", "region": "华南", "amount": 13500},
    {"month": "2026-07", "region": "华东", "amount": 22200},
    {"month": "2026-07", "region": "华北", "amount": 14400},
    {"month": "2026-07", "region": "华南", "amount": 15200},
]

_TARGETS = {"2026-06": 45000, "2026-07": 50000}


@server.tool()
def query_sales(month: str) -> str:
    """查询指定月份的销售明细。month 格式 YYYY-MM，例如 2026-07。"""
    rows = [r for r in _DB if r["month"] == month]
    if not rows:
        return f"没有 {month} 的数据。可用月份：2026-06、2026-07"
    lines = [f"{r['region']}: {r['amount']}" for r in rows]
    total = sum(r["amount"] for r in rows)
    return f"{month} 销售明细：\n" + "\n".join(lines) + f"\n合计: {total}"


@server.tool()
def get_target(month: str) -> str:
    """查询指定月份的销售目标。month 格式 YYYY-MM。"""
    t = _TARGETS.get(month)
    return f"{month} 目标: {t}" if t else f"没有 {month} 的目标数据"


def main() -> None:
    """控制台入口。同一份代码两种传输方式，靠环境变量切。"""
    transport = os.environ.get("MCP_TRANSPORT", "stdio")
    if transport == "http":
        server.run(transport="streamable-http")   # 默认 127.0.0.1:8000/mcp
    else:
        server.run(transport="stdio")


if __name__ == "__main__":
    main()
