"""mcp-sales-db：可发布形态的销售数据 MCP 服务端。"""

__version__ = "0.1.0"
