"""集中管理配置，所有环境变量只在这里读一次。"""

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()

# 智谱按量付费与 Coding Plan 的 endpoint 不同，别填错
ZHIPU_BASE_URL_PAYG = "https://open.bigmodel.cn/api/paas/v4/"
ZHIPU_BASE_URL_CODING = "https://open.bigmodel.cn/api/coding/paas/v4/"


@dataclass(frozen=True)
class Settings:
    zhipu_api_key: str
    zhipu_base_url: str
    model: str
    judge_model: str
    temperature: float
    max_concurrency: int
    langsmith_enabled: bool
    langsmith_project: str
    use_llm_judge: bool
    disable_thinking: bool

    def require_llm(self) -> None:
        if not self.zhipu_api_key:
            raise SystemExit(
                "缺少 ZHIPU_API_KEY。\n"
                "  1) cp .env.example .env\n"
                "  2) 去 https://bigmodel.cn 控制台拿 key 填进去"
            )

    def require_langsmith(self) -> None:
        if not os.getenv("LANGSMITH_API_KEY"):
            raise SystemExit(
                "缺少 LANGSMITH_API_KEY。\n"
                "  去 https://smith.langchain.com → Settings → API Keys 生成，"
                "填入 .env"
            )


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def load_settings() -> Settings:
    coding_plan = _bool("ZHIPU_CODING_PLAN", False)
    return Settings(
        zhipu_api_key=os.getenv("ZHIPU_API_KEY", ""),
        zhipu_base_url=os.getenv(
            "ZHIPU_BASE_URL",
            ZHIPU_BASE_URL_CODING if coding_plan else ZHIPU_BASE_URL_PAYG,
        ),
        model=os.getenv("GLM_MODEL", "glm-4.7-flash"),
        judge_model=os.getenv("GLM_JUDGE_MODEL", "glm-4.7-flash"),
        # GLM 要求 temperature > 0，不接受 0
        temperature=float(os.getenv("GLM_TEMPERATURE", "0.1")),
        # 免费 flash 模型限 1 并发；付费档可以调大
        max_concurrency=int(os.getenv("EVAL_MAX_CONCURRENCY", "1")),
        langsmith_enabled=_bool("LANGSMITH_TRACING", True),
        langsmith_project=os.getenv("LANGSMITH_PROJECT", "glm-kefu-demo"),
        use_llm_judge=_bool("USE_LLM_JUDGE", False),
        disable_thinking=_bool("GLM_DISABLE_THINKING", True),
    )


settings = load_settings()
