"""FastAPI 服务：/chat 问答，/feedback 回写用户点赞点踩。

启动：uvicorn src.server:app --reload --port 8000
文档：http://localhost:8000/docs
"""

from fastapi import FastAPI, HTTPException
from langsmith import Client
from pydantic import BaseModel, Field

from .config import settings
from .pipeline import PROMPT_VERSION, answer_question

app = FastAPI(title="GLM 客服助手 + LangSmith", version="1.0.0")
ls_client = Client()


class ChatRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=500)
    user_id: str = "anonymous"


class ChatResponse(BaseModel):
    answer: str
    run_id: str | None
    sources: list[str]


class FeedbackRequest(BaseModel):
    run_id: str
    score: int = Field(..., ge=0, le=1, description="1=点赞，0=点踩")
    comment: str | None = None


@app.get("/health")
def health() -> dict:
    return {
        "ok": True,
        "model": settings.model,
        "tracing": settings.langsmith_enabled,
        "prompt_version": PROMPT_VERSION,
    }


@app.post("/chat", response_model=ChatResponse)
def chat_endpoint(req: ChatRequest) -> ChatResponse:
    try:
        result = answer_question(
            req.question,
            # metadata 和 tags 会挂在这条 trace 上，线上排查时可以按它们过滤
            langsmith_extra={
                "metadata": {
                    "user_id": req.user_id,
                    "prompt_version": PROMPT_VERSION,
                    "model": settings.model,
                },
                "tags": ["prod", "api"],
            },
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"模型调用失败：{exc}") from exc
    return ChatResponse(**result)


@app.post("/feedback")
def feedback_endpoint(req: FeedbackRequest) -> dict:
    """把前端的点赞点踩写回 LangSmith。

    这是最省力的测试集来源：攒一段时间的点踩样本，
    直接在 LangSmith 界面上一键加进回归数据集。
    """
    try:
        ls_client.create_feedback(
            run_id=req.run_id,
            key="user_thumbs",
            score=req.score,
            comment=req.comment,
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"反馈写入失败：{exc}") from exc
    return {"ok": True}
