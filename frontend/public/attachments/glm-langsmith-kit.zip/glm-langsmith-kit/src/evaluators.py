"""评估器集合。

签名固定为 (inputs, outputs, reference_outputs)，返回 {"key", "score", "comment"}。
返回 score=None 表示该用例不适用这个指标，LangSmith 会跳过而不是记 0 分——
这一点很重要，否则防幻觉的负例会把命中率指标拖低，数字就没法看了。
"""

import json

from .config import settings
from .llm import chat
from .pipeline import REFUSAL_TEXT

REFUSAL_MARKERS = (REFUSAL_TEXT, "没有查到", "没有相关", "抱歉", "无法提供")


def key_fact_hit(inputs, outputs, reference_outputs) -> dict:
    """答案里是否包含期望的关键事实"""
    if reference_outputs.get("should_refuse"):
        return {"key": "关键信息命中", "score": None}
    expected = reference_outputs.get("answer", "")
    return {
        "key": "关键信息命中",
        "score": int(expected in outputs.get("answer", "")),
        "comment": f"期望包含：{expected}",
    }


def refuses_when_unknown(inputs, outputs, reference_outputs) -> dict:
    """知识库外的问题有没有老实拒答（防幻觉）"""
    if not reference_outputs.get("should_refuse"):
        return {"key": "正确拒答", "score": None}
    answer = outputs.get("answer", "")
    return {"key": "正确拒答", "score": int(any(m in answer for m in REFUSAL_MARKERS))}


def no_hallucination_number(inputs, outputs, reference_outputs) -> dict:
    """粗筛：拒答类用例里冒出了具体数字，基本就是在编"""
    if not reference_outputs.get("should_refuse"):
        return {"key": "无编造数字", "score": None}
    answer = outputs.get("answer", "")
    has_digit = any(ch.isdigit() for ch in answer)
    return {
        "key": "无编造数字",
        "score": int(not has_digit),
        "comment": "拒答时出现数字，疑似编造" if has_digit else "",
    }


def is_concise(inputs, outputs, reference_outputs) -> dict:
    """长度约束，prompt 里要求 50 字内，留点余量按 60 判"""
    length = len(outputs.get("answer", ""))
    return {"key": "简洁度", "score": int(length <= 60), "comment": f"实际 {length} 字"}


JUDGE_PROMPT = """你是严格的客服质量审核员。请判断客服回答是否合格。

合格标准：
- 准确回应了用户问题
- 没有编造资料以外的信息
- 语气友好专业

用户问题：{question}
客服回答：{answer}
参考答案要点：{reference}

只输出 JSON，不要任何其他内容，格式：
{{"score": 0 或 1, "reason": "20字内理由"}}"""


def llm_judge(inputs, outputs, reference_outputs) -> dict:
    """LLM-as-judge：规则指标覆盖不到的主观质量，交给模型打分。

    默认关闭（USE_LLM_JUDGE=false），因为它会额外消耗 token 和时间。
    """
    if not settings.use_llm_judge:
        return {"key": "模型评审", "score": None}

    raw = chat(
        [
            {
                "role": "user",
                "content": JUDGE_PROMPT.format(
                    question=inputs.get("question", ""),
                    answer=outputs.get("answer", ""),
                    reference=reference_outputs.get("answer") or "（应当拒答）",
                ),
            }
        ],
        model=settings.judge_model,
        temperature=0.01,
        max_tokens=200,
    )
    try:
        cleaned = raw.replace("```json", "").replace("```", "").strip()
        parsed = json.loads(cleaned)
        return {
            "key": "模型评审",
            "score": int(parsed.get("score", 0)),
            "comment": str(parsed.get("reason", ""))[:100],
        }
    except (json.JSONDecodeError, ValueError, TypeError):
        # 评审器自己挂了不该让整个实验失败，记 None 并留下现场
        return {"key": "模型评审", "score": None, "comment": f"解析失败：{raw[:60]}"}


ALL_EVALUATORS = [
    key_fact_hit,
    refuses_when_unknown,
    no_hallucination_number,
    is_concise,
    llm_judge,
]
