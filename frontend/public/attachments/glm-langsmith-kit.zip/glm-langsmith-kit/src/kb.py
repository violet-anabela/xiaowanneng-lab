"""知识库与检索。

这里用最朴素的关键词匹配，目的是让 demo 零依赖可跑。
要换成真的向量检索，只需要替换 retrieve() 的函数体，
签名和 @traceable 装饰器都不用动，LangSmith 照样能追踪。
"""

from langsmith import traceable

KNOWLEDGE_BASE: list[dict] = [
    {
        "id": "kb_refund",
        "keywords": ["退款", "退货", "能退", "退回", "无理由", "不想要"],
        "content": "订单签收后 7 天内可无理由退款，生鲜、定制类商品除外。",
    },
    {
        "id": "kb_shipping",
        "keywords": ["包邮", "运费", "邮费", "快递费", "多少钱寄"],
        "content": "单笔订单满 99 元包邮，未满收取 8 元运费。",
    },
    {
        "id": "kb_invoice",
        "keywords": ["发票", "开票", "报销"],
        "content": "下单后 30 天内可在订单详情页自助申请电子发票。",
    },
    {
        "id": "kb_service_hours",
        "keywords": ["客服", "上班", "工作时间", "几点", "在线"],
        "content": "在线客服工作时间为每天 9:00-21:00。",
    },
    {
        "id": "kb_delivery",
        "keywords": ["发货", "多久到", "物流", "几天到"],
        "content": "现货商品 48 小时内发货，预售商品以商品页标注时间为准。",
    },
]


@traceable(run_type="retriever")
def retrieve(question: str, top_k: int = 3) -> list[dict]:
    """返回命中的资料。run_type='retriever' 让 LangSmith 用检索专用视图展示。"""
    scored = []
    for item in KNOWLEDGE_BASE:
        hits = sum(1 for kw in item["keywords"] if kw in question)
        if hits:
            scored.append((hits, item))
    scored.sort(key=lambda x: -x[0])
    return [
        {"id": item["id"], "page_content": item["content"], "score": hits}
        for hits, item in scored[:top_k]
    ]
