"""GLM + LangSmith 客服问答示例包。"""

__version__ = "1.0.0"
