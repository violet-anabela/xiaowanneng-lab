"""智谱客户端。用 wrap_openai 包一层，所有调用自动上报 LangSmith。"""

from functools import lru_cache

from openai import OpenAI

from langsmith.wrappers import wrap_openai

from .config import settings


@lru_cache(maxsize=1)
def get_client() -> OpenAI:
    settings.require_llm()
    raw = OpenAI(
        api_key=settings.zhipu_api_key,
        base_url=settings.zhipu_base_url,  # 智谱是 /api/paas/v4/，不是 /v1/
        timeout=60.0,
        max_retries=2,
    )
    # LANGSMITH_TRACING=false 时 wrap 依然安全，只是不上报
    return wrap_openai(raw)


def chat(
    messages: list[dict],
    *,
    model: str | None = None,
    temperature: float | None = None,
    max_tokens: int = 1024,
) -> str:
    """统一的对话入口，返回纯文本。"""
    extra: dict = {}
    if settings.disable_thinking:
        # GLM-4.5+ 默认开启深度思考，会明显变慢；关掉更适合客服这类短问答
        extra["thinking"] = {"type": "disabled"}

    resp = get_client().chat.completions.create(
        model=model or settings.model,
        messages=messages,
        temperature=settings.temperature if temperature is None else temperature,
        max_tokens=max_tokens,
        extra_body=extra or None,
    )
    content = resp.choices[0].message.content
    return (content or "").strip()
