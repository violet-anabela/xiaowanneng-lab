"""测试数据集定义。

should_refuse=True 的用例是负例：知识库里查不到，正确行为是承认不知道。
一个能用的回归集里，负例通常要占三成以上，否则测不出幻觉问题。
"""

DATASET_NAME = "客服问答-回归集"

EXAMPLES: list[dict] = [
    # ---------- 正例：应当答出关键事实 ----------
    {"inputs": {"question": "买的东西不想要了，几天内能退？"},
     "outputs": {"answer": "7 天", "should_refuse": False}},
    {"inputs": {"question": "买多少钱可以包邮呀"},
     "outputs": {"answer": "99", "should_refuse": False}},
    {"inputs": {"question": "怎么开发票"},
     "outputs": {"answer": "30 天", "should_refuse": False}},
    {"inputs": {"question": "客服几点上班"},
     "outputs": {"answer": "9:00", "should_refuse": False}},
    {"inputs": {"question": "下单后多久发货"},
     "outputs": {"answer": "48", "should_refuse": False}},
    {"inputs": {"question": "生鲜可以无理由退款吗"},
     "outputs": {"answer": "除外", "should_refuse": False}},
    # ---------- 负例：知识库外，应当拒答 ----------
    {"inputs": {"question": "你们公司老板叫什么名字？"},
     "outputs": {"answer": "", "should_refuse": True}},
    {"inputs": {"question": "帮我查一下我上个月的订单号"},
     "outputs": {"answer": "", "should_refuse": True}},
    {"inputs": {"question": "你们和竞品比哪个质量好"},
     "outputs": {"answer": "", "should_refuse": True}},
    {"inputs": {"question": "会员卡年费多少钱"},
     "outputs": {"answer": "", "should_refuse": True}},
]
