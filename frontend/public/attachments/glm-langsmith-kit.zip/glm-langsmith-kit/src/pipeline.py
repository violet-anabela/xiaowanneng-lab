"""被追踪的客服问答链路。这是唯一一份业务逻辑，服务和评估都复用它。"""

from langsmith import traceable
from langsmith.run_helpers import get_current_run_tree

from .kb import retrieve
from .llm import chat

# 拒答话术里必须出现的标记，评估器会据此判断模型有没有老实承认不知道
REFUSAL_TEXT = "抱歉，我这边没有查到相关信息"

SYSTEM_PROMPT = f"""你是电商平台的在线客服助手。

规则：
1. 只能依据【资料】中的内容回答，不得使用任何资料以外的知识。
2. 【资料】中没有提到的信息，必须原样回答「{REFUSAL_TEXT}」，绝对不要猜测或编造。
3. 回答控制在 50 字以内，语气友好、直接给结论。
4. 不要提及"资料"、"文档"、"上下文"这类内部词汇。"""

PROMPT_VERSION = "v1"  # 每次改上面的 prompt 就 +1，评估时用它区分实验


@traceable
def build_prompt(question: str, docs: list[dict]) -> list[dict]:
    context = (
        "\n".join(f"- {d['page_content']}" for d in docs) if docs else "（无相关资料）"
    )
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"【资料】\n{context}\n\n【问题】\n{question}"},
    ]


@traceable(run_type="llm")
def generate(question: str, docs: list[dict]) -> str:
    return chat(build_prompt(question, docs))


@traceable(name="客服问答")
def answer_question(question: str) -> dict:
    """完整链路。返回 answer 以及 run_id（前端可拿它回写用户反馈）。"""
    docs = retrieve(question)
    answer = generate(question, docs)

    run = get_current_run_tree()
    return {
        "answer": answer,
        "run_id": str(run.id) if run else None,
        "sources": [d["id"] for d in docs],
    }
