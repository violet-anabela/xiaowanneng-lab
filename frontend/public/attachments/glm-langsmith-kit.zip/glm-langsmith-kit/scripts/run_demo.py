"""追踪演示：跑几个问题，去 LangSmith 看完整调用树。

    python -m scripts.run_demo
    python -m scripts.run_demo "自定义问题"
"""

import sys

from src.config import settings
from src.pipeline import PROMPT_VERSION, answer_question

DEFAULT_QUESTIONS = [
    "买的东西不想要了，几天内能退？",
    "买多少钱可以包邮呀",
    "你们公司老板叫什么名字？",  # 负例：看模型会不会瞎编
]


def main() -> None:
    settings.require_llm()
    questions = sys.argv[1:] or DEFAULT_QUESTIONS

    print(f"模型：{settings.model}　追踪：{'开' if settings.langsmith_enabled else '关'}")
    print("-" * 60)

    for q in questions:
        print(f"\n【问】{q}")
        result = answer_question(
            q,
            langsmith_extra={
                "metadata": {"user_id": "cli_demo", "prompt_version": PROMPT_VERSION},
                "tags": ["demo", "cli"],
            },
        )
        print(f"【答】{result['answer']}")
        print(f"　命中资料：{result['sources'] or '无'}")
        print(f"　run_id：{result['run_id']}")

    if settings.langsmith_enabled:
        print(
            f"\n完成。去 https://smith.langchain.com 打开项目"
            f"「{settings.langsmith_project}」查看调用链。"
        )


if __name__ == "__main__":
    main()
