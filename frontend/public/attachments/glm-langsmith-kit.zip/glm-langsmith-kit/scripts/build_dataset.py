"""创建或更新测试数据集（可反复运行，已存在就只补新用例）。

    python -m scripts.build_dataset
"""

from langsmith import Client

from src.config import settings
from src.dataset import DATASET_NAME, EXAMPLES


def main() -> None:
    settings.require_langsmith()
    ls = Client()

    if ls.has_dataset(dataset_name=DATASET_NAME):
        dataset = ls.read_dataset(dataset_name=DATASET_NAME)
        existing = {
            ex.inputs.get("question") for ex in ls.list_examples(dataset_id=dataset.id)
        }
        new = [e for e in EXAMPLES if e["inputs"]["question"] not in existing]
        if not new:
            print(f"数据集「{DATASET_NAME}」已是最新，共 {len(existing)} 条用例。")
            return
        ls.create_examples(dataset_id=dataset.id, examples=new)
        print(f"数据集「{DATASET_NAME}」新增 {len(new)} 条用例。")
        return

    dataset = ls.create_dataset(
        dataset_name=DATASET_NAME,
        description="电商客服问答回归集：6 条正例 + 4 条防幻觉负例",
    )
    ls.create_examples(dataset_id=dataset.id, examples=EXAMPLES)
    print(f"数据集「{DATASET_NAME}」创建完成，共 {len(EXAMPLES)} 条用例。")
    print(f"https://smith.langchain.com/datasets/{dataset.id}")


if __name__ == "__main__":
    main()
