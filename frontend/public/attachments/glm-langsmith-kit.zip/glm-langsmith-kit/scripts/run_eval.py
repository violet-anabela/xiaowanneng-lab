"""跑评估实验。

    python -m scripts.run_eval                 # 用 prompt 版本号作实验名
    python -m scripts.run_eval my-experiment   # 自定义实验名

改完 src/pipeline.py 的 prompt、把 PROMPT_VERSION 加一，再跑一次，
然后在数据集页面勾选两个实验点 Compare，逐条对比差异。
"""

import sys

from langsmith import Client

from src.config import settings
from src.dataset import DATASET_NAME
from src.evaluators import ALL_EVALUATORS
from src.pipeline import PROMPT_VERSION, answer_question
from scripts.build_dataset import main as build_dataset


def target(inputs: dict) -> dict:
    """待测目标。直接调生产链路，保证测的就是线上那份逻辑。"""
    return answer_question(inputs["question"])


def main() -> None:
    settings.require_langsmith()
    settings.require_llm()

    build_dataset()  # 确保数据集存在

    prefix = sys.argv[1] if len(sys.argv) > 1 else f"glm-{PROMPT_VERSION}"
    print(f"\n实验名：{prefix}")
    print(f"模型：{settings.model}　并发：{settings.max_concurrency}")
    print(f"LLM 评审：{'开' if settings.use_llm_judge else '关'}")
    print("-" * 60)

    results = Client().evaluate(
        target,
        data=DATASET_NAME,
        evaluators=ALL_EVALUATORS,
        experiment_prefix=prefix,
        # 免费 flash 模型限 1 并发，调大会撞 429
        max_concurrency=settings.max_concurrency,
        metadata={
            "model": settings.model,
            "prompt_version": PROMPT_VERSION,
            "temperature": settings.temperature,
        },
    )

    print("\n实验完成，上面的链接点进去看逐条评分和完整 trace。")
    print("对比技巧：改 prompt → PROMPT_VERSION 加一 → 重跑 → 数据集页面 Compare。")
    return results


if __name__ == "__main__":
    main()
