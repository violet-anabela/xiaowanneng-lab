"""离线测试：不需要任何 key、不联网，用来保证改代码没把逻辑改坏。

    pytest -q
"""

from src.dataset import EXAMPLES
from src.evaluators import (
    is_concise,
    key_fact_hit,
    no_hallucination_number,
    refuses_when_unknown,
)
from src.kb import retrieve
from src.pipeline import REFUSAL_TEXT, build_prompt


class TestRetrieve:
    def test_positive_cases_all_hit(self):
        """数据集里所有正例都必须能检索到资料，否则模型无从作答"""
        for ex in EXAMPLES:
            if ex["outputs"]["should_refuse"]:
                continue
            q = ex["inputs"]["question"]
            assert retrieve(q), f"正例检索为空：{q}"

    def test_negative_cases_return_nothing(self):
        """负例必须检索为空，这是拒答的前提"""
        for ex in EXAMPLES:
            if not ex["outputs"]["should_refuse"]:
                continue
            q = ex["inputs"]["question"]
            assert retrieve(q) == [], f"负例意外命中资料：{q}"

    def test_respects_top_k(self):
        assert len(retrieve("退款 包邮 发票 客服 发货", top_k=2)) == 2


class TestPrompt:
    def test_docs_are_injected(self):
        msgs = build_prompt("几天能退", [{"page_content": "7 天内可退"}])
        assert "7 天内可退" in msgs[1]["content"]

    def test_empty_docs_marked_explicitly(self):
        msgs = build_prompt("老板是谁", [])
        assert "无相关资料" in msgs[1]["content"]

    def test_refusal_text_in_system_prompt(self):
        msgs = build_prompt("x", [])
        assert REFUSAL_TEXT in msgs[0]["content"]


class TestEvaluators:
    def test_key_fact_hit(self):
        ref = {"answer": "7 天", "should_refuse": False}
        assert key_fact_hit({}, {"answer": "签收后 7 天内可退"}, ref)["score"] == 1
        assert key_fact_hit({}, {"answer": "签收后 15 天内可退"}, ref)["score"] == 0

    def test_key_fact_skipped_for_negatives(self):
        ref = {"answer": "", "should_refuse": True}
        assert key_fact_hit({}, {"answer": REFUSAL_TEXT}, ref)["score"] is None

    def test_refusal_detection(self):
        ref = {"should_refuse": True}
        assert refuses_when_unknown({}, {"answer": REFUSAL_TEXT}, ref)["score"] == 1
        assert refuses_when_unknown({}, {"answer": "我们老板姓王"}, ref)["score"] == 0

    def test_hallucinated_number_flagged(self):
        ref = {"should_refuse": True}
        assert no_hallucination_number({}, {"answer": "年费 199 元"}, ref)["score"] == 0
        assert no_hallucination_number({}, {"answer": REFUSAL_TEXT}, ref)["score"] == 1

    def test_concise(self):
        ref = {"should_refuse": False}
        assert is_concise({}, {"answer": "满 99 包邮"}, ref)["score"] == 1
        assert is_concise({}, {"answer": "啊" * 100}, ref)["score"] == 0


class TestDatasetIntegrity:
    def test_no_duplicate_questions(self):
        qs = [e["inputs"]["question"] for e in EXAMPLES]
        assert len(qs) == len(set(qs))

    def test_enough_negatives(self):
        """负例占比低于 30% 就测不出幻觉问题"""
        neg = sum(1 for e in EXAMPLES if e["outputs"]["should_refuse"])
        assert neg / len(EXAMPLES) >= 0.3
