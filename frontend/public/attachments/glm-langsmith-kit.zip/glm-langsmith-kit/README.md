# GLM + LangSmith 客服问答完整示例

一个可直接运行的 RAG 客服问答项目，接入 **智谱 GLM** 作为模型、**LangSmith** 做全链路追踪与离线评估。

包含：链路追踪、关键词检索、离线回归评估（含防幻觉指标与 LLM-as-judge）、FastAPI 服务、用户反馈回流、13 个不联网的单元测试。

## 快速开始

```bash
# 1. 装依赖并生成 .env
make install

# 2. 编辑 .env，填两个 key（见下表）
#    然后先跑测试确认环境没问题（不需要 key，不联网）
make test

# 3. 追踪演示
make demo

# 4. 评估实验
make eval

# 5. 起服务
make serve      # http://localhost:8000/docs
```

不用 make 也行：

```bash
pip install -r requirements.txt
cp .env.example .env
pytest -q
python -m scripts.run_demo
python -m scripts.run_eval
uvicorn src.server:app --reload --port 8000
```

## 两个 Key

| 变量 | 获取地址 | 说明 |
|---|---|---|
| `LANGSMITH_API_KEY` | https://smith.langchain.com → Settings → API Keys | `lsv2_pt_` 开头，免费额度每月 5000 条 trace |
| `ZHIPU_API_KEY` | https://bigmodel.cn → 控制台 | `glm-4.7-flash` 长期免费，跑完整个 demo 也不花钱 |

别搞混：LangSmith 的 key 只用来上传日志，智谱的 key 才是调模型的。

## 目录结构

```
glm-langsmith-kit/
├── src/
│   ├── config.py       环境变量集中管理 + 缺 key 时的友好报错
│   ├── llm.py          智谱客户端（wrap_openai 自动上报）
│   ├── kb.py           知识库与检索 ← 换成向量库只改这里
│   ├── pipeline.py     被追踪的问答链路（唯一一份业务逻辑）
│   ├── evaluators.py   5 个评估器，含 LLM-as-judge
│   ├── dataset.py      10 条测试用例（6 正例 + 4 防幻觉负例）
│   └── server.py       FastAPI：/chat、/feedback、/health
├── scripts/
│   ├── run_demo.py       追踪演示
│   ├── build_dataset.py  上传数据集（幂等，可反复跑）
│   └── run_eval.py       跑评估实验
├── tests/test_offline.py 13 个离线测试，不需要 key
├── .env.example
├── Makefile
└── requirements.txt
```

## 跑完你会看到什么

**`make demo`** → LangSmith 项目里出现这样一棵调用树：

```
客服问答                    1.8s
├── retrieve                0.00s   ← retriever 视图，直接看命中了哪几条资料
└── generate                1.8s
    ├── build_prompt        0.00s   ← 看拼好的 prompt 原文
    └── ChatOpenAI          1.8s   ← 看 token 数、耗时、完整请求响应
```

**`make eval`** → 一张 10 用例 × 5 指标的评分表：

| 指标 | 作用 | 适用范围 |
|---|---|---|
| 关键信息命中 | 答案含不含正确事实（7 天 / 99 元 / 48 小时…） | 仅正例 |
| 正确拒答 | 知识库外的问题有没有老实说不知道 | 仅负例 |
| 无编造数字 | 拒答时冒出具体数字 = 大概率在编 | 仅负例 |
| 简洁度 | 有没有遵守 50 字约束 | 全部 |
| 模型评审 | 主观质量，LLM-as-judge（默认关） | 全部 |

指标不适用的用例返回 `score=None`，LangSmith 会跳过而不是记 0 分。**这个细节很关键**——否则防幻觉负例会把命中率指标拖低，数字就没法解读了。

## 核心用法：对比实验

这是 LangSmith 真正省时间的地方。改 prompt 前后各跑一次，逐条看差异：

```bash
make eval                        # 基线，实验名 glm-v1

# 编辑 src/pipeline.py 的 SYSTEM_PROMPT
# 把 PROMPT_VERSION 改成 "v2"

make eval                        # 新版，实验名 glm-v2
```

然后去数据集页面勾选两个实验 → **Compare**。哪条变好了、哪条被你改崩了，一眼看到，不用凭感觉。

想同时比模型也一样：

```bash
GLM_MODEL=glm-4.7 python -m scripts.run_eval glm-4.7-baseline
GLM_MODEL=glm-5   python -m scripts.run_eval glm-5-baseline
```

## 用户反馈回流

`/chat` 返回的 `run_id` 给前端存着，用户点赞点踩时调 `/feedback`：

```bash
curl -X POST localhost:8000/chat \
  -H 'Content-Type: application/json' \
  -d '{"question":"几天内能退款","user_id":"u_123"}'
# → {"answer":"...","run_id":"abc-123","sources":["kb_refund"]}

curl -X POST localhost:8000/feedback \
  -H 'Content-Type: application/json' \
  -d '{"run_id":"abc-123","score":0,"comment":"答错了"}'
```

攒一批点踩样本后，在 LangSmith 界面上可以一键把它们加进回归数据集。**这是最省力的测试集来源**——比自己凭空编用例有效得多，因为它们是真实用户真的问错过的问题。

## 换成真的向量检索

只改 `src/kb.py` 里 `retrieve()` 的函数体，签名和 `@traceable` 装饰器都不用动：

```python
@traceable(run_type="retriever")
def retrieve(question: str, top_k: int = 3) -> list[dict]:
    docs = your_vectorstore.similarity_search(question, k=top_k)
    return [{"id": d.metadata["id"], "page_content": d.page_content} for d in docs]
```

`tests/test_offline.py` 里的检索测试会立刻告诉你有没有改坏。智谱的 embedding 模型（`embedding-3`）也是 OpenAI 兼容的，可以直接用 `src/llm.py` 里那个 client 调。

## 智谱相关的坑（代码里已规避）

| 坑 | 说明 | 代码位置 |
|---|---|---|
| base_url | 必须是 `/api/paas/v4/`，不是 `/v1/`，写错直接 404 | `config.py` |
| Coding Plan | 买的是 GLM Coding Plan 的话 endpoint 是 `/api/coding/paas/v4`，和按量付费不同 | `ZHIPU_CODING_PLAN=true` |
| temperature | GLM 要求 > 0，写 `0` 可能被拒 | 默认 0.1 |
| 并发限制 | 免费 flash 限 1 并发，评估并发调大会 429 | `EVAL_MAX_CONCURRENCY=1` |
| 深度思考 | GLM-4.5+ 默认开启，短问答场景明显变慢 | `GLM_DISABLE_THINKING=true` |
| 模型名 | `glm-4.5-flash` 已于 2026-01-30 下线，会静默路由到 `glm-4.7-flash`，不报错但跑的是新模型 | 直接写新名字 |

## 数据合规

默认所有 prompt 和回复都会上传到 LangSmith 的海外服务器。涉及用户敏感数据的话，上生产前先解决这件事，三个选项：

1. `.env` 里打开 `LANGSMITH_HIDE_INPUTS=true` / `LANGSMITH_HIDE_OUTPUTS=true`，只上传调用结构和耗时，不传内容（会损失大部分调试价值）
2. 上 LangSmith 企业版自托管
3. 换 Langfuse，开源可完全私有化部署，API 风格和 LangSmith 很接近，迁移成本不高

另外 `LANGSMITH_TRACING=false` 可以完全关闭上报，一行代码都不用改。

## 关于评估的一点提醒

回归集是**刹车**，不是方向盘。它能告诉你有没有改崩，不能告诉你怎么改好。别在同一个 10 条用例的数据集上反复调 prompt 调到过拟合——真要认真做，用例数量得上到几十上百条，并且持续从线上点踩样本里补充。
