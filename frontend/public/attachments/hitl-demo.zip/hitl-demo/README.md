# HITL 演示（危险工具先问人）

配套文章：小完能实验室 → 手账 → 《让 agent 动手之前先问你一句》

## 装

```bash
python -m venv .venv && .venv/bin/pip install -r requirements.txt
cp .env.example .env      # 填上智谱的 key
```

## 跑

```bash
.venv/bin/python server.py     # 网页版，自己开浏览器
.venv/bin/python cli.py        # 命令行版
```

## 文件

| 文件 | 是什么 |
|---|---|
| `server.py` | 网页版后端，三个接口。直接跑它就行 |
| `ui.html` | 网页版前端，单文件零依赖，由 `server.py` 吐出来 |
| `cli.py` | 命令行版，同一套配置的另一种前端 |
| `replay_demo.py` | 20 行小实验，不用大模型不用网络 |
| `checkpoints.sqlite` | 存档，`server.py` 自动建。删了等于清空所有会话 |

三个工具（删文件、读文件、发邮件）都是假的，只返回一句字符串，不会真删也不会真发。
大模型是真的，每次点批准都是一次真实调用。
