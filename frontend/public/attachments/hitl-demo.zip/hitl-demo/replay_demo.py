"""证明 resume 是「重跑被打断那一格」，不是「接着往下跑」。

不用大模型，不用网络，直接跑：
    .venv/bin/python docs/langchain/deepagent/hitl/为什么会重跑.py

看输出里 [第二步] 中断之前的代码 这行打印了几次。
"""

from typing import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt


class S(TypedDict):
    log: list[str]


def 第一步(state: S):
    print("   [第一步] 我跑了")
    return {"log": state["log"] + ["第一步"]}


def 第二步(state: S):
    print("   [第二步] 中断之前的代码")        # ← 关键：这行会打印两次
    decision = interrupt("批不批？")           # ← 第一次跑到这儿抛异常退出
    print(f"   [第二步] 中断之后的代码，拿到：{decision}")   # ← 这行只打印一次
    return {"log": state["log"] + [f"第二步({decision})"]}


graph = StateGraph(S)
graph.add_node("第一步", 第一步)
graph.add_node("第二步", 第二步)
graph.add_edge(START, "第一步")
graph.add_edge("第一步", "第二步")
graph.add_edge("第二步", END)

app = graph.compile(checkpointer=MemorySaver())
config = {"configurable": {"thread_id": "x"}}

print("① 第一次 invoke（跑到中断为止）")
app.invoke({"log": []}, config)

print("\n② resume（人回答了 approve）")
result = app.invoke(Command(resume="approve"), config)

print("\n最终 log:", result["log"])
