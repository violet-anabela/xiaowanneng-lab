import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from deepagents import create_deep_agent
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

load_dotenv(Path(__file__).with_name(".env"))


@tool
def remove_file(path: str) -> str:
    """Delete a file from the filesystem."""
    return f"Deleted {path}"


@tool
def fetch_file(path: str) -> str:
    """Read a file from the filesystem."""
    return f"Contents of {path}"


@tool
def notify_email(to: str, subject: str, body: str) -> str:
    """Send an email."""
    return f"Sent email to {to}"


# Checkpointer is REQUIRED for human-in-the-loop
checkpointer = MemorySaver()

agent = create_deep_agent(
    # 没配 OpenRouter，用 .env 里的智谱 key 走 OpenAI 兼容接口
    model=ChatOpenAI(
        model=os.getenv("GLM_MODEL", "glm-5.2"),
        api_key=os.environ["ZHIPU_API_KEY"],
        base_url="https://open.bigmodel.cn/api/paas/v4/",
        temperature=0.1,
    ),
    tools=[remove_file, fetch_file, notify_email],
    interrupt_on={
        "remove_file": True,  # Default: approve, edit, reject, respond
        "fetch_file": False,  # No interrupts needed
        "notify_email": {"allowed_decisions": ["approve", "reject"]},  # No editing
    },
    checkpointer=checkpointer,  # Required!
)


def review(action_requests, review_configs) -> list[dict]:
    """把每个待执行的工具调用摊给用户看，收决定。菜单按该工具允许的决定生成。"""
    allowed_by_name = {c["action_name"]: c["allowed_decisions"] for c in review_configs}
    keys = {"a": "approve", "e": "edit", "r": "reject", "s": "respond"}
    decisions = []

    for request in action_requests:
        name = request["name"]
        args = request["args"]
        allowed = allowed_by_name.get(name, ["approve", "reject"])
        menu = {k: v for k, v in keys.items() if v in allowed}

        print(f"\nAgent 想调用 {name}({json.dumps(args, ensure_ascii=False)})")
        print("  " + "  ".join(f"[{k}] {v}" for k, v in menu.items()))
        while True:
            answer = input(f"选一个 {'/'.join(menu)}：").strip().lower()
            if answer in menu:
                break

        kind = menu[answer]
        if kind == "approve":
            decisions.append({"type": "approve"})
        elif kind == "edit":
            # edited_action 里的参数才是真正传给工具的
            edited = json.loads(input("新参数（JSON）："))
            decisions.append({"type": "edit", "edited_action": {"name": name, "args": edited}})
        elif kind == "reject":
            # 回一条 status="error" 的 ToolMessage，工具不执行
            decisions.append({"type": "reject", "message": input("为什么不让做：").strip()})
        else:
            # respond：自己代替工具作答，回 status="success" 的 ToolMessage
            decisions.append({"type": "respond", "message": input("你替它回什么：").strip()})

    return decisions


# .venv/bin/python cli.py                 # 跑默认问题
# .venv/bin/python cli.py "换成自己的问题"
if __name__ == "__main__":
    # 不带参数也能直接跑。点名工具是故意的：deepagents 自带的 delete_file 会抢活，
    # 不点名就只会踩到 notify_email 一个中断点，看不到 edit / respond 那两条路。
    question = " ".join(sys.argv[1:]) or (
        "用 remove_file 删掉 /tmp/a.log，再用 notify_email 发邮件到 ops@example.com 汇报结果"
    )
    payload = {"messages": [{"role": "user", "content": question}]}
    # thread_id 是必须的，中断点存在这个 thread 下面才恢复得回来
    config = {"configurable": {"thread_id": "hitl"}}

    while True:
        result = agent.invoke(payload, config)
        interrupts = result.get("__interrupt__")
        if not interrupts:
            break
        # 中断的 value 是 HITLRequest：{"action_requests": [...], "review_configs": [...]}
        hitl = interrupts[0].value
        # decisions 的个数和顺序必须跟 action_requests 一一对应
        payload = Command(resume={"decisions": review(hitl["action_requests"], hitl["review_configs"])})

    print(result["messages"][-1].content)
