"""cli.py 的 Web 版：把 CLI 里的 input() 换成两次 HTTP 请求。

跑起来（自己起服务、自己开浏览器，什么都不用输）：
    .venv/bin/python server.py
"""

import os
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from deepagents import create_deep_agent
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
from langgraph.types import Command
from pydantic import BaseModel

HERE = Path(__file__).parent
load_dotenv(HERE / ".env")

# 存档落在这个文件里，所以后端重启、换进程都还在（对比 MemorySaver 的进程内存）
DB_PATH = HERE / "checkpoints.sqlite"

DEFAULT_QUESTION = "用 remove_file 删掉 /tmp/a.log，再用 notify_email 发邮件到 ops@example.com 汇报结果"


@tool
def remove_file(path: str) -> str:
    """Delete a file from the filesystem."""
    return f"Deleted {path}"


@tool
def fetch_file(path: str) -> str:
    """Read a file from the filesystem."""
    return f"Contents of {path}"


@tool
def notify_email(to: str, subject: str, body: str) -> str:
    """Send an email."""
    return f"Sent email to {to}"


def build_agent(checkpointer):
    return create_deep_agent(
        model=ChatOpenAI(
            model=os.getenv("GLM_MODEL", "glm-5.2"),
            api_key=os.environ["ZHIPU_API_KEY"],
            base_url="https://open.bigmodel.cn/api/paas/v4/",
            temperature=0.1,
        ),
        tools=[remove_file, fetch_file, notify_email],
        interrupt_on={
            "remove_file": True,  # approve / edit / reject / respond 四条路都开
            "fetch_file": False,  # 只读，不拦
            "notify_email": {"allowed_decisions": ["approve", "reject"]},  # 不许改参数
        },
        checkpointer=checkpointer,
    )


@asynccontextmanager
async def lifespan(app: FastAPI):
    # AsyncSqliteSaver 是个 async context manager，连接的生命周期跟着 app 走
    async with AsyncSqliteSaver.from_conn_string(str(DB_PATH)) as checkpointer:
        app.state.agent = build_agent(checkpointer)
        yield


app = FastAPI(lifespan=lifespan)


class StartBody(BaseModel):
    message: str = DEFAULT_QUESTION
    thread_id: str | None = None


class ResumeBody(BaseModel):
    thread_id: str
    decisions: list[dict]


def _chat(messages) -> list[dict]:
    """把 LangChain 的消息对象摊成前端好画的形状。"""
    out = []
    for m in messages:
        out.append({
            "role": m.type,                                   # human / ai / tool
            "text": m.content if isinstance(m.content, str) else str(m.content),
            "tool": getattr(m, "name", None) if m.type == "tool" else None,
            "calls": [c["name"] for c in (getattr(m, "tool_calls", None) or [])],
        })
    return out


async def _snapshot(thread_id: str, result: dict | None = None) -> dict:
    """前端要的东西：整段对话 + 有没有卡在等人。"""
    agent = app.state.agent
    state = await agent.aget_state({"configurable": {"thread_id": thread_id}})
    snap = {
        "thread_id": thread_id,
        "messages": _chat(state.values.get("messages", [])),
        "status": "done",
    }

    # 中断信息两个来源：刚 invoke 完的返回值里，或者从存档里捞
    hitl = None
    if result and (interrupts := result.get("__interrupt__")):
        hitl = interrupts[0].value
    elif state.tasks and state.tasks[0].interrupts:
        hitl = state.tasks[0].interrupts[0].value

    if hitl:
        # action_requests 画卡片，review_configs 决定显示哪几个按钮
        snap["status"] = "interrupted"
        snap["action_requests"] = hitl["action_requests"]
        snap["review_configs"] = hitl["review_configs"]
    return snap


@app.get("/")
async def index():
    return FileResponse(HERE / "ui.html")


@app.post("/api/runs")
async def start(body: StartBody):
    """第 1 次请求：跑到第一个中断点就返回，连接不挂着等人。"""
    thread_id = body.thread_id or f"t-{uuid.uuid4().hex[:8]}"
    config = {"configurable": {"thread_id": thread_id}}
    payload = {"messages": [{"role": "user", "content": body.message}]}
    result = await app.state.agent.ainvoke(payload, config)
    return await _snapshot(thread_id, result)


@app.post("/api/runs/resume")
async def resume(body: ResumeBody):
    """第 2 次请求：带着 thread_id 和决定回来，从存档接上。"""
    config = {"configurable": {"thread_id": body.thread_id}}

    # 关键校验：存档不存在时 LangGraph 不会报错，会当一次全新运行从头跑，
    # 结果是用户点了「批准删除」却触发了一段空白上下文的新对话。
    state = await app.state.agent.aget_state(config)
    if not state.next:
        raise HTTPException(404, f"thread {body.thread_id} 没有待恢复的中断")

    result = await app.state.agent.ainvoke(Command(resume={"decisions": body.decisions}), config)
    return await _snapshot(body.thread_id, result)


@app.get("/api/threads/{thread_id}")
async def peek(thread_id: str):
    """刷新页面/重启后端之后，用它把整段对话和「还悬着的审批」一起捞回来。"""
    state = await app.state.agent.aget_state({"configurable": {"thread_id": thread_id}})
    if not state.values.get("messages"):
        raise HTTPException(404, f"没有编号 {thread_id} 这个会话")
    return await _snapshot(thread_id)


if __name__ == "__main__":
    import threading
    import webbrowser

    import uvicorn

    PORT = 8099
    # 服务起来大概要 1 秒，等一下再开浏览器（不想自动弹的话删掉这两行）
    threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    uvicorn.run(app, host="127.0.0.1", port=PORT)
