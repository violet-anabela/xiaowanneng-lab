"""
skill 机制的全部实现 —— 与模型、框架无关。

三阶段 progressive disclosure 里，这个文件只负责第 1 阶段「发现」。
第 2 阶段「激活」和第 3 阶段「执行」由模型自己调 read_file / bash 完成，
不需要任何代码。
"""
from pathlib import Path


def parse_frontmatter(path: Path):
    """手撸 YAML frontmatter 解析，只取 name / description。

    故意不用 pyyaml —— 想让你看清这步有多没技术含量。
    """
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None
    end = text.find("\n---", 3)
    if end == -1:
        return None

    fm, key, buf = {}, None, []
    for line in text[3:end].splitlines():
        if line.strip() and not line[0].isspace() and ":" in line:
            if key:
                fm[key] = " ".join(buf).strip()
            key, _, rest = line.partition(":")
            key, buf = key.strip(), [rest.strip()]
        elif key:
            buf.append(line.strip())
    if key:
        fm[key] = " ".join(buf).strip()

    # description 常写成 >- 或 | 折叠块
    for k, v in fm.items():
        if v.startswith((">-", ">", "|-", "|")):
            fm[k] = v.lstrip(">|-").strip()

    return fm if "name" in fm and "description" in fm else None


def discover(skill_dirs):
    """阶段1 发现：扫目录，只读 frontmatter。SKILL.md 正文一个字都不碰。"""
    out = []
    for d in skill_dirs:
        d = Path(d)
        if not d.is_dir():
            continue
        for md in sorted(d.glob("*/SKILL.md")):
            fm = parse_frontmatter(md)
            if fm:
                out.append({"name": fm["name"],
                            "desc": fm["description"],
                            "path": str(md.resolve())})
    return out


def build_system_prompt(skills):
    """把清单拼成 XML 塞进 system prompt。只有 name/description/path。"""
    catalog = "\n".join(
        f"  <skill>\n    <name>{s['name']}</name>\n"
        f"    <description>{s['desc']}</description>\n"
        f"    <location>{s['path']}</location>\n  </skill>"
        for s in skills
    )
    return (
        "你是一个能使用 skill 的 agent。下面是可用 skill 清单，"
        "只有名字、描述和文件路径，正文没有加载。\n\n"
        "判断某个 skill 与当前任务相关时，先用 read_file 读它的 <location>，"
        "再按里面的指示执行。SKILL.md 引用的其他文件（references/、scripts/、"
        "assets/），只在真正需要时才读或执行。不相关就直接干活，不用勉强套。\n\n"
        f"<available_skills>\n{catalog}\n</available_skills>"
    )
