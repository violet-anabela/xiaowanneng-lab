#!/usr/bin/env python3
"""
最小 Skill Agent（LangGraph 版）

用法：
  1. 编辑 config.yaml，填上 api_key
  2. pip install -r requirements.txt
  3. python agent.py "把 sales.csv 做成七月销售报告"

看清 skill 是怎么被调用的：
  阶段1 发现   启动时只把 name+description 注入 system prompt
  阶段2 激活   模型自己判断相关，调 read_file 读 SKILL.md
  阶段3 执行   按需读 references/assets、跑 scripts
"""
import atexit, os, shutil, subprocess, sys, tempfile
from pathlib import Path

import yaml
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent   # LangGraph 1.0 起在 langchain 包里

from skills_core import discover, build_system_prompt

HERE = Path(__file__).parent
CFG = yaml.safe_load((HERE / "config.yaml").read_text(encoding="utf-8"))

# ══════════════════ 解释器兼容层 ══════════════════
# 问题：SKILL.md 里写 python 还是 python3？
#   macOS 没有 python，Windows 没有 python3，venv 里两个可能都不是你想要的。
# 解法：不让模型猜。建一个临时 bin 目录，把 python / python3 都指向当前解释器，
#      塞进 PATH 最前面。这样 SKILL.md 里随便写哪个都对，skill 保持可移植。

PYTHON = CFG.get("run", {}).get("python") or sys.executable


def _build_shim_dir() -> str:
    """返回一个含 python / python3 的目录，二者都指向 PYTHON。"""
    d = Path(tempfile.mkdtemp(prefix="skillagent-bin-"))
    for name in ("python", "python3"):
        try:
            if os.name == "nt":
                (d / f"{name}.bat").write_text(f'@echo off\r\n"{PYTHON}" %*\r\n')
            else:
                target = d / name
                try:
                    target.symlink_to(PYTHON)
                except (OSError, NotImplementedError):
                    target.write_text(f'#!/bin/sh\nexec "{PYTHON}" "$@"\n')
                    target.chmod(0o755)
        except OSError:
            pass
    return str(d)


SHIM_DIR = _build_shim_dir()
ENV = {**os.environ, "PATH": SHIM_DIR + os.pathsep + os.environ.get("PATH", "")}
atexit.register(lambda: shutil.rmtree(SHIM_DIR, ignore_errors=True))


# ══════════════════ 工具（跟 skill 无关，任何 agent 都得有）══════════════════

@tool
def read_file(path: str) -> str:
    """读取文件内容。用来加载 SKILL.md 以及它引用的文档。"""
    p = Path(path)
    if not p.is_file():
        return f"错误：文件不存在 {path}"
    try:
        return p.read_text(encoding="utf-8")[:50_000]
    except UnicodeDecodeError:
        # assets 里的字体、图片等二进制，不该进上下文
        return f"[二进制文件 {p.stat().st_size} 字节。在代码里引用路径即可，别读内容。]"


@tool
def bash(command: str) -> str:
    """执行 shell 命令。用来运行 skill 自带的脚本、处理文件。

    工作目录固定为项目根目录（agent.py 所在目录），命令里不需要 cd。
    数据文件如 sales.csv 就在这里，脚本在 skills/<name>/scripts/ 下。
    python 和 python3 均可用，都指向本项目的解释器。
    """
    try:
        r = subprocess.run(command, shell=True, capture_output=True,
                           text=True, timeout=60, cwd=HERE, env=ENV)
    except subprocess.TimeoutExpired:
        return "错误：命令超时（60s）"
    return (r.stdout + r.stderr)[:20_000] or f"(无输出，退出码 {r.returncode})"


# ══════════════════ trace：让三个阶段可见 ══════════════════

C = "\033[36m"; Y = "\033[33m"; G = "\033[90m"; R = "\033[0m"


def label(arg: str) -> str:
    if arg.endswith("SKILL.md"):
        return f"{C}阶段2 激活 —— SKILL.md 正文进上下文{R}"
    if "/scripts/" in arg:
        return f"{C}阶段3 执行 —— 跑脚本（源码不进，只有输出进）{R}"
    if "/references/" in arg or "/assets/" in arg:
        return f"{C}阶段3 执行 —— 按需读附带文件{R}"
    return f"{G}       工具调用{R}"


# ══════════════════ 主流程 ══════════════════

def main(task: str) -> None:
    llm_cfg = CFG["llm"]
    if not llm_cfg.get("api_key") or "填" in str(llm_cfg["api_key"]):
        sys.exit("请先在 config.yaml 里填上 api_key")

    # ---- 阶段1：发现 ----
    skill_dirs = [HERE / d for d in CFG["skills"]["dirs"]]
    skills = discover(skill_dirs)
    system_prompt = build_system_prompt(skills)

    verbose = CFG["run"].get("verbose", True)
    if verbose:
        print("=" * 70)
        print(f"模型   {llm_cfg['model']} @ {llm_cfg.get('base_url') or 'openai'}")
        print(f"{C}阶段1 发现{R} 扫到 {len(skills)} 个 skill，"
              f"只装了 name+description ≈{len(system_prompt) // 3} tokens")
        for s in skills:
            print(f"       · {s['name']}")
        print(f"任务   {task}")
        print("=" * 70)

    agent = create_agent(
        model=ChatOpenAI(
            model=llm_cfg["model"],
            api_key=llm_cfg["api_key"],
            base_url=llm_cfg.get("base_url") or None,
            temperature=llm_cfg.get("temperature", 0),
        ),
        tools=[read_file, bash],
        system_prompt=system_prompt,          # ← 唯一跟 skill 有关的一行
    )

    # ---- 阶段2、3 全在模型手里，我们只旁观 ----
    for chunk in agent.stream(
        {"messages": [("user", task)]},
        {"recursion_limit": CFG["run"].get("max_steps", 40)},
        stream_mode="values",
    ):
        msg = chunk["messages"][-1]
        if msg.type == "ai":
            if msg.content:
                print(f"\n{Y}模型:{R} {msg.content}")
            for tc in msg.tool_calls or []:
                arg = tc["args"].get("path") or tc["args"].get("command", "")
                if verbose:
                    print(f"{label(arg)}\n       → {arg}")
        elif msg.type == "tool" and verbose:
            out = str(msg.content)
            print(f"{G}       ← 返回 {len(out)} 字符{R}")
            # 看起来像报错就打出来，否则你根本不知道脚本挂没挂
            if CFG["run"].get("show_errors", True) and any(
                k in out for k in ("not found", "Traceback", "错误：",
                                   "No such file", "Error", "error:")):
                first = out.strip().splitlines()
                print(f"\033[31m       ⚠ {first[0][:150]}{R}")
                if len(first) > 1:
                    print(f"\033[31m         ...{first[-1][:150]}{R}")

    print("\n" + "=" * 70 + "\n完成")


if __name__ == "__main__":
    main(" ".join(sys.argv[1:]) or "把 sales.csv 做成七月销售报告")
