# 最小 Skill Agent

一个能看清 **skill 到底怎么被调用**的最小 agent。全部代码 200 行。

## 快速开始

```bash
pip install -r requirements.txt

# 编辑 config.yaml，填上 api_key（默认配的是智谱）
python agent.py "把 sales.csv 做成七月销售报告"
```

## 你会看到什么

```
阶段1 发现 扫到 2 个 skill，只装了 name+description ≈300 tokens
       · commit-msg
       · csv-report

模型: 任务提到「销售报告」，匹配 csv-report。先读它。
阶段2 激活 —— SKILL.md 正文进上下文
       → skills/csv-report/SKILL.md

模型: 第 1 步让我跑 summarize.py。
阶段3 执行 —— 跑脚本（源码不进，只有输出进）
       → python skills/csv-report/scripts/summarize.py sales.csv

模型: 第 2 步说要读格式规范。
阶段3 执行 —— 按需读附带文件
       → skills/csv-report/references/format.md
```

注意 `commit-msg` 全程没被碰过，它的正文一直躺在磁盘上。

## 核心结论

**"调用 skill" 不是一个 API 调用，就是模型用普通的 read_file 工具读了个 md 文件。**

你在代码里找不到 `invoke_skill()` 这种函数，因为它不存在。
整个机制只有两个函数（都在 `skills_core.py`）：

- `discover()` —— 扫目录，只读 frontmatter，正文不碰
- `build_system_prompt()` —— 拼成 XML 塞进 system

剩下全靠模型自己判断 + read_file。

## 文件说明

```
config.yaml              模型、skill 目录、运行参数
agent.py                 LangGraph agent（loop + 工具 + trace）
skills_core.py           skill 机制全在这，52 行，与框架无关
requirements.txt
sales.csv                测试数据
skills/
  csv-report/            带 references + scripts + assets 三件套的完整示例
    SKILL.md             ← 阶段2 读这个
    references/format.md ← 读进上下文的文档
    scripts/summarize.py ← 只有输出进上下文
    assets/report_template.md  ← 模板，供复制
  commit-msg/            纯文本 skill，用来对照「不触发」
```

## 三个目录的区别

| 目录 | 怎么用 | 进上下文的部分 |
|---|---|---|
| `scripts/` | 跑它 | 只有 stdout |
| `references/` | 模型读它 | 全文 |
| `assets/` | 别人用它（脚本/浏览器/用户） | 通常不进 |

## 建议做的实验

**改 description，看触发率变化。** 这是整套机制里唯一需要调优的东西。

把 `skills/csv-report/SKILL.md` 的 description 改成笼统的一句：

```yaml
description: 处理数据。
```

再跑，大概率不触发了。改回原来带「销售报告、月报、CSV 汇总」这些触发词的版本，又好了。

**结论：skill 的准确率押在那段自然语言上，不在代码里。**

## 换模型

改 `config.yaml` 的 `llm` 三行即可。文件里已经写好了智谱 / OpenAI / DeepSeek / 通义的对照。

## 加自己的 skill

在 `skills/` 下新建文件夹，放个 SKILL.md：

```markdown
---
name: my-skill
description: 什么时候用它。把用户可能说的原话都写进来，并写明什么时候不该用。
---

# 步骤
1. ...
```

不用改任何代码，重启就生效。

## 跨平台

脚本在 macOS / Linux / Windows 上行为一致，无需改动：

- **解释器**：启动时建一个临时 bin 目录，把 `python` 和 `python3` 都指向运行
  `agent.py` 的那个解释器（含 venv），塞进 PATH 最前面。所以 SKILL.md 里写
  `python` 还是 `python3` 都对，**skill 文件保持可移植**。Windows 下生成 `.bat`，
  POSIX 下用软链（失败则退回 sh wrapper）。退出时自动清理。
- **想指定别的解释器**：`config.yaml` 里 `run.python` 填绝对路径。
- **工作目录**：所有命令的 cwd 固定为项目根目录，SKILL.md 里用相对路径即可。

写自己的 skill 时，命令直接写 `python skills/xxx/scripts/foo.py data.csv` 就行。

## 生产环境还缺什么

这是教学用的骨架，真上线要补：

- **bash 沙箱** —— 现在是裸 `subprocess.run(shell=True)`，模型让干啥就干啥
- **token 预算** —— 现在只有 `max_steps` 熔断
- **tracing** —— 记录每次选了哪个 skill、读了哪些文件，否则出问题没法查
- **skill 来源审查** —— 恶意 SKILL.md 等于往你的上下文注入指令 + 往机器上放可执行脚本
