---
name: commit-msg
description: 用户要写、检查或修改 git commit message 时使用。触发词：commit message、提交信息、conventional commits。不适用于：写代码、做报告。
---

# Commit Message

用 conventional commits 格式：`type(scope): subject`
type 只能是 feat / fix / docs / refactor / test / chore
subject 用祈使句，不超过 50 字符，结尾不加句号。
