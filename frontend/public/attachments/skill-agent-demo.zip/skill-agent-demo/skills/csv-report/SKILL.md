---
name: csv-report
description: 把 CSV 数据做成销售报告时使用。触发词：销售报告、月报、CSV 汇总、数据报表、把表格做成报告。会按公司规范计算指标并套用固定格式。不适用于：单纯读 CSV、写代码、做图表。
---

# CSV 销售报告

工作目录已经是项目根目录，下面的相对路径可直接使用，不要 cd，不要 find。

## 步骤

1. 计算汇总指标。**必须跑脚本，不要自己心算**：

   ```
   python skills/csv-report/scripts/summarize.py sales.csv
   ```

   脚本输出 JSON。如果报错，把错误告诉用户并停下，不要绕过脚本自己算。

2. 写报告前读格式规范：`skills/csv-report/references/format.md`

3. 输出模板：`skills/csv-report/assets/report_template.md`，复制一份填进去。
