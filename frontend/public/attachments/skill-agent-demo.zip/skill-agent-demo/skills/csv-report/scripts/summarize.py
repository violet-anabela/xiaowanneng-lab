import csv, json, sys
rows = list(csv.DictReader(open(sys.argv[1], encoding="utf-8")))
total = sum(float(r["amount"]) for r in rows)
by_region = {}
for r in rows:
    by_region[r["region"]] = by_region.get(r["region"], 0) + float(r["amount"])
print(json.dumps({"total": total, "count": len(rows), "by_region": by_region},
                 ensure_ascii=False, indent=2))
